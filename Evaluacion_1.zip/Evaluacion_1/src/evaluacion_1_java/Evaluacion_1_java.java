package evaluacion_1_java;

import java.util.Scanner;

public class Evaluacion_1_java {

    public static void main(String[] args) {
        System.out.println("Ingresa la promocion: ");
        Scanner sc = new Scanner(System.in);
        int numeroprom = sc.nextInt();

        switch (numeroprom) {
            case 1:

                int[] prom1 = new int[2];
                prom1[0] = 2;//lapices
                prom1[1] = 3;//cuadernos

                //enero 
                System.out.println("Ingresa la cantidad de promociones de enero");
                int cantpromoenero = sc.nextInt();
                int totalcuadernosenero = prom1[0] * cantpromoenero;
                int totallapicesenero = prom1[1] * cantpromoenero;
                double valorventasenero = 13370 * cantpromoenero;

                //febrero
                System.out.println("Ingresa la cantidad de promociones de febrero");
                int cantpromofebrero = sc.nextInt();
                int totalcuadernofebrero = prom1[0] * cantpromofebrero;
                int totallapicesfebrero = prom1[1] * cantpromofebrero;
                double valorventasfebrero = 13370 * cantpromofebrero;

                //marzo
                System.out.println("Ingresa la cantidad de promociones de marzo");
                int cantpromomarzo = sc.nextInt();
                int totalcuadernomarzo = prom1[0] * cantpromomarzo;
                int totallapicesmarzo = prom1[1] * cantpromomarzo;
                double valorventasmarzo = 13370 * cantpromomarzo;

                //abril
                System.out.println("Ingresa la cantidad de promociones de abril");
                int cantpromoabril = sc.nextInt();
                int totalcuadernoabril = prom1[0] * cantpromoabril;
                int totallapicesabril = prom1[1] * cantpromoabril;
                double valorventasabril = 13370 * cantpromoabril;

                //mayo
                System.out.println("Ingresa la cantidad de promociones de mayo");
                int cantpromomayo = sc.nextInt();
                int totalcuadernomayo = prom1[0] * cantpromomayo;
                int totallapicesmayo = prom1[1] * cantpromomayo;
                double valorventasmayo = 13370 * cantpromomayo;

                //junio
                System.out.println("Ingresa la cantidad de promociones de junio");
                int cantpromojunio = sc.nextInt();
                int totalcuadernojunio = prom1[0] * cantpromojunio;
                int totallapicesjunio = prom1[1] * cantpromojunio;
                double valorventasjunio = 13370 * cantpromojunio;

                //julio
                System.out.println("Ingresa la cantidad de promociones de julio");
                int cantpromojulio = sc.nextInt();
                int totalcuadernojulio = prom1[0] * cantpromojulio;
                int totallapicesjulio = prom1[1] * cantpromojulio;
                double valorventasjulio = 13370 * cantpromojulio;

                //agosto
                System.out.println("Ingresa la cantidad de promociones de agosto");
                int cantpromoagosto = sc.nextInt();
                int totalcuadernoagosto = prom1[0] * cantpromoagosto;
                int totallapicesagosto = prom1[1] * cantpromoagosto;
                double valorventasagosto = 13370 * cantpromoagosto;

                //septiembre
                System.out.println("Ingresa la cantidad de promociones de septiembre");
                int cantpromoseptiembre = sc.nextInt();
                int totalcuadernoseptiembre = prom1[0] * cantpromoseptiembre;
                int totallapicesseptiembre = prom1[1] * cantpromoseptiembre;
                double valorventasseptiembre = 13370 * cantpromoseptiembre;

                //octubre 
                System.out.println("Ingresa la cantidad de promociones de octubre");
                int cantpromooctubre = sc.nextInt();
                int totalcuadernooctubre = prom1[0] * cantpromooctubre;
                int totallapicesoctubre = prom1[1] * cantpromooctubre;
                double valorventasoctubre = 13370 * cantpromooctubre;

                //noviembre
                System.out.println("Ingresa la cantidad de promociones de noviembre");
                int cantpromonoviembre = sc.nextInt();
                int totalcuadernonoviembre = prom1[0] * cantpromonoviembre;
                int totallapicesnoviembre = prom1[1] * cantpromonoviembre;
                double valorventasnoviembre = 13370 * cantpromonoviembre;

                //diciembre
                System.out.println("Ingresa la cantidad de promociones de diciembre");
                int cantpromodiciembre = sc.nextInt();
                int totalcuadernodiciembre = prom1[0] * cantpromodiciembre;
                int totallapicesdiciembre = prom1[1] * cantpromodiciembre;
                double valorventasdiciembre = 13370 * cantpromodiciembre;

                System.out.println("======================================");
                System.out.println("Resumen:  ");
                System.out.println("                                      ");
                System.out.println("Total de lapices del mes de enero: " + totallapicesenero);
                System.out.println("Total de cuadernos del mes de enero: " + totalcuadernosenero);
                System.out.println("Total de ventas del mes de enero $" + Math.round(valorventasenero));
                System.out.println("======================================");
                System.out.println("Total de lapices del mes de febrero: " + totallapicesfebrero);
                System.out.println("Total de cuadernos del mes de febrero: " + totalcuadernofebrero);
                System.out.println("Total de ventas del mes de febrero $" + Math.round(valorventasfebrero));
                System.out.println("======================================");
                System.out.println("Total de lapices del mes de marzo: " + totallapicesmarzo);
                System.out.println("Total de cuadernos del mes de marzo: " + totalcuadernomarzo);
                System.out.println("Total de ventas del mes de marzo $" + Math.round(valorventasmarzo));
                System.out.println("======================================");
                System.out.println("Total de lapices del mes de abril: " + totallapicesabril);
                System.out.println("Total de cuadernos del mes de abril: " + totalcuadernoabril);
                System.out.println("Total de ventas del mes de abril $" + Math.round(valorventasabril));
                System.out.println("======================================");
                System.out.println("Total de lapices del mes de mayo: " + totallapicesmayo);
                System.out.println("Total de cuadernos del mes de mayo: " + totalcuadernomayo);
                System.out.println("Total de ventas del mes de mayo $" + Math.round(valorventasmayo));
                System.out.println("======================================");
                System.out.println("Total de lapices del mes de junio: " + totallapicesjunio);
                System.out.println("Total de cuadernos del mes de junio: " + totalcuadernojunio);
                System.out.println("Total de ventas del mes de junio $" + Math.round(valorventasjunio));
                System.out.println("======================================");
                System.out.println("Total de lapices del mes de julio: " + totallapicesjulio);
                System.out.println("Total de cuadernos del mes de julio: " + totalcuadernojulio);
                System.out.println("Total de ventas del mes de julio $" + Math.round(valorventasjulio));
                System.out.println("======================================");
                System.out.println("Total de lapices del mes de agosto: " + totallapicesagosto);
                System.out.println("Total de cuadernos del mes de agosto: " + totalcuadernoagosto);
                System.out.println("Total de ventas del mes de agosto $" + Math.round(valorventasagosto));
                System.out.println("======================================");
                System.out.println("Total de lapices del mes de septiembre: " + totallapicesseptiembre);
                System.out.println("Total de cuadernos del mes de septiembre: " + totalcuadernoseptiembre);
                System.out.println("Total de ventas del mes de septiembre $" + Math.round(valorventasseptiembre));
                System.out.println("======================================");
                System.out.println("Total de lapices del mes de octubre: " + totallapicesoctubre);
                System.out.println("Total de cuadernos del mes de octubre: " + totalcuadernooctubre);
                System.out.println("Total de ventas del mes de octubre $" + Math.round(valorventasoctubre));
                System.out.println("======================================");
                System.out.println("Total de lapices del mes de noviembre: " + totallapicesnoviembre);
                System.out.println("Total de cuadernos del mes de noviembre: " + totalcuadernonoviembre);
                System.out.println("Total de ventas del mes de noviembre $" + Math.round(valorventasnoviembre));
                System.out.println("======================================");
                System.out.println("Total de lapices del mes de diciembre: " + totallapicesdiciembre);
                System.out.println("Total de cuadernos del mes de diciembre: " + totalcuadernodiciembre);
                System.out.println("Total de ventas del mes de noviembre $" + Math.round(valorventasdiciembre));
                
                
                
                
                
                
                
                
                double valorventasaño = valorventasenero+
                        valorventasfebrero+
                        valorventasmarzo+valorventasabril+
                        valorventasmayo+
                        valorventasjunio+
                        valorventasjulio+
                        valorventasagosto+
                        valorventasseptiembre+
                        valorventasoctubre+
                        valorventasnoviembre+
                        valorventasdiciembre;
                System.out.println(valorventasaño);
                if (valorventasaño>750000) {
                  
                    
                }
                
                break;
            case 2:
                //cambiar los valores de prom 1 a los valores de prom 2 y renombrar el array

                int[] prom2 = new int[2];
                prom2[0] = 6;//lapices
                prom2[1] = 4;//cuadernos

                //enero 
                System.out.println("Ingresa la cantidad de promociones de enero");
                int cantpromoenero1 = sc.nextInt();
                int totalcuadernosenero1 = prom2[0] * cantpromoenero1;
                int totallapicesenero1 = prom2[1] * cantpromoenero1;
                double valorventasenero1 = 27800 * cantpromoenero1;

                //febrero
                System.out.println("Ingresa la cantidad de promociones de febrero");
                int cantpromofebrero1 = sc.nextInt();
                int totalcuadernofebrero1 = prom2[0] * cantpromofebrero1;
                int totallapicesfebrero1 = prom2[1] * cantpromofebrero1;
                double valorventasfebrero1 = 27800 * cantpromofebrero1;

                //marzo
                System.out.println("Ingresa la cantidad de promociones de marzo");
                int cantpromomarzo1 = sc.nextInt();
                int totalcuadernomarzo1 = prom2[0] * cantpromomarzo1;
                int totallapicesmarzo1 = prom2[1] * cantpromomarzo1;
                double valorventasmarzo1 = 27800 * cantpromomarzo1;

                //abril
                System.out.println("Ingresa la cantidad de promociones de abril");
                int cantpromoabril1 = sc.nextInt();
                int totalcuadernoabril1 = prom2[0] * cantpromoabril1;
                int totallapicesabril1 = prom2[1] * cantpromoabril1;
                double valorventasabril1 = 27800 * cantpromoabril1;

                //mayo
                System.out.println("Ingresa la cantidad de promociones de mayo");
                int cantpromomayo1 = sc.nextInt();
                int totalcuadernomayo1 = prom2[0] * cantpromomayo1;
                int totallapicesmayo1 = prom2[1] * cantpromomayo1;
                double valorventasmayo1 = 27800 * cantpromomayo1;

                //junio
                System.out.println("Ingresa la cantidad de promociones de junio");
                int cantpromojunio1 = sc.nextInt();
                int totalcuadernojunio1 = prom2[0] * cantpromojunio1;
                int totallapicesjunio1 = prom2[1] * cantpromojunio1;
                double valorventasjunio1 = 27800 * cantpromojunio1;

                //julio
                System.out.println("Ingresa la cantidad de promociones de julio");
                int cantpromojulio1 = sc.nextInt();
                int totalcuadernojulio1 = prom2[0] * cantpromojulio1;
                int totallapicesjulio1 = prom2[1] * cantpromojulio1;
                double valorventasjulio1 = 27800 * cantpromojulio1;

                //agosto
                System.out.println("Ingresa la cantidad de promociones de agosto");
                int cantpromoagosto1 = sc.nextInt();
                int totalcuadernoagosto1 = prom2[0] * cantpromoagosto1;
                int totallapicesagosto1 = prom2[1] * cantpromoagosto1;
                double valorventasagosto1 = 27800 * cantpromoagosto1;

                //septiembre
                System.out.println("Ingresa la cantidad de promociones de septiembre");
                int cantpromoseptiembre1 = sc.nextInt();
                int totalcuadernoseptiembre1 = prom2[0] * cantpromoseptiembre1;
                int totallapicesseptiembre1 = prom2[1] * cantpromoseptiembre1;
                double valorventasseptiembre1 = 27800 * cantpromoseptiembre1;

                //octubre 
                System.out.println("Ingresa la cantidad de promociones de octubre");
                int cantpromooctubre1 = sc.nextInt();
                int totalcuadernooctubre1 = prom2[0] * cantpromooctubre1;
                int totallapicesoctubre1 = prom2[1] * cantpromooctubre1;
                double valorventasoctubre1 = 27800 * cantpromooctubre1;

                //noviembre
                System.out.println("Ingresa la cantidad de promociones de noviembre");
                int cantpromonoviembre1 = sc.nextInt();
                int totalcuadernonoviembre1 = prom2[0] * cantpromonoviembre1;
                int totallapicesnoviembre1 = prom2[1] * cantpromonoviembre1;
                double valorventasnoviembre1 = 27800 * cantpromonoviembre1;

                //diciembre
                System.out.println("Ingresa la cantidad de promociones de diciembre");
                int cantpromodiciembre1 = sc.nextInt();
                int totalcuadernodiciembre1 = prom2[0] * cantpromodiciembre1;
                int totallapicesdiciembre1 = prom2[1] * cantpromodiciembre1;
                double valorventasdiciembre1 = 27800 * cantpromodiciembre1;

                System.out.println("======================================");
                System.out.println("Resumen:  ");
                System.out.println("                                      ");
                System.out.println("======================================");
                System.out.println("Total de lapices del mes de enero: " + totallapicesenero1);
                System.out.println("Total de cuadernos del mes de enero: " + totalcuadernosenero1);
                System.out.println("Total de ventas del mes de enero $" + Math.round(valorventasenero1));
                System.out.println("======================================");
                System.out.println("Total de lapices del mes de febrero: " + totallapicesfebrero1);
                System.out.println("Total de cuadernos del mes de febrero: " + totalcuadernofebrero1);
                System.out.println("Total de ventas del mes de febrero $" + Math.round(valorventasfebrero1));
                System.out.println("======================================");
                System.out.println("Total de lapices del mes de marzo: " + totallapicesmarzo1);
                System.out.println("Total de cuadernos del mes de marzo: " + totalcuadernomarzo1);
                System.out.println("Total de ventas del mes de marzo $" + Math.round(valorventasmarzo1));
                System.out.println("======================================");
                System.out.println("Total de lapices del mes de abril: " + totallapicesabril1);
                System.out.println("Total de cuadernos del mes de abril: " + totalcuadernoabril1);
                System.out.println("Total de ventas del mes de abril $" + Math.round(valorventasabril1));
                System.out.println("======================================");
                System.out.println("Total de lapices del mes de mayo: " + totallapicesmayo1);
                System.out.println("Total de cuadernos del mes de mayo: " + totalcuadernomayo1);
                System.out.println("Total de ventas del mes de mayo $" + Math.round(valorventasmayo1));
                System.out.println("======================================");
                System.out.println("Total de lapices del mes de junio: " + totallapicesjunio1);
                System.out.println("Total de cuadernos del mes de junio: " + totalcuadernojunio1);
                System.out.println("Total de ventas del mes de junio $" + Math.round(valorventasjunio1));
                System.out.println("======================================");
                System.out.println("Total de lapices del mes de julio: " + totallapicesjulio1);
                System.out.println("Total de cuadernos del mes de julio: " + totalcuadernojulio1);
                System.out.println("Total de ventas del mes de julio $" + Math.round(valorventasjulio1));
                System.out.println("======================================");
                System.out.println("Total de lapices del mes de agosto: " + totallapicesagosto1);
                System.out.println("Total de cuadernos del mes de agosto: " + totalcuadernoagosto1);
                System.out.println("Total de ventas del mes de agosto $" + Math.round(valorventasagosto1));
                System.out.println("======================================");
                System.out.println("Total de lapices del mes de septiembre: " + totallapicesseptiembre1);
                System.out.println("Total de cuadernos del mes de septiembre: " + totalcuadernoseptiembre1);
                System.out.println("Total de ventas del mes de septiembre $" + Math.round(valorventasseptiembre1));
                System.out.println("======================================");
                System.out.println("Total de lapices del mes de octubre: " + totallapicesoctubre1);
                System.out.println("Total de cuadernos del mes de octubre: " + totalcuadernooctubre1);
                System.out.println("Total de ventas del mes de octubre $" + Math.round(valorventasoctubre1));
                System.out.println("======================================");
                System.out.println("Total de lapices del mes de noviembre: " + totallapicesnoviembre1);
                System.out.println("Total de cuadernos del mes de noviembre: " + totalcuadernonoviembre1);
                System.out.println("Total de ventas del mes de noviembre $" + Math.round(valorventasnoviembre1));
                System.out.println("======================================");
                System.out.println("Total de lapices del mes de diciembre: " + totallapicesdiciembre1);
                System.out.println("Total de cuadernos del mes de diciembre: " + totalcuadernodiciembre1);
                System.out.println("Total de ventas del mes de noviembre $" + Math.round(valorventasdiciembre1));

                break;

            default:
                throw new AssertionError();
        }
    }

}