package evaluacion_1_java;

public class Correcion_evaluacion1 {

    public static void main(String[] args) {
        int a[][] = {{2, 6},/*lapices,*/
                     {3, 4}/*cuadernos*/};
        
        
        
        
        //////////////////////////////////
        //promocion 3
        int [] b = new int [2];
        b[0]= 5;//lapices
        //////////////////////////////////
        
        int [] enerofebrero3 =        {89};//
        int [] marzoabril3 =          {98};
        int [] mayojunio3 =           {110};
        int [] julioagosto3 =         {130};
        int [] septiembreoctubre3 =   {150};
        int [] noviembrediciembre3 =  {170};
        
        
        
        
        int enerofebrero[][] =       {{114/*enero*/,   100/*febrero*/},/*tipo 1*/
                                      {130/*enero*/,   68/*febrero*/}};/*tipo 2*/
        int marzoabril[][] =         {{80,/*marzo*/   120/*abril*/},/*tipo 1*/
                                      {60,/*marzo*/   100/*abril*/}};/*tipo 2*/
        int mayojunio[][] =          {{347,/*mayo*/   120/*junio*/},/*tipo 1*/
                                      {123,/*mayo*/   122/*junio*/}};/*tipo 2*/
        int julioagosto[][] =        {{124,/*julio*/   121/*agosto*/},/*tipo 1*/
                                      {125,/*julio*/   126/*agosto*/}};/*tipo 2*/
        int septiembreoctubre[][] =  {{127,/*septiembre*/   128/*octubre*/},/*tipo 1*/
                                      {129,/*septiembre*/   130/*octubre*/}};/*tipo 2*/
        int noviembrediciembre[][] = {{131,/*marzo*/   132/*abril*/},/*tipo 1*/
                                      {133,/*marzo*/   134/*abril*/}};/*tipo 2*/

        int ventas[][] = {{13370, 27800},
        {13370, 27800}
        };
        int c[][] = new int[2][2];
        int total[][] = new int[2][2];
        
        //enero y febrero
        
        int totallapicesenero = enerofebrero3[0]*b[0];
        int valortotalprom3enero = enerofebrero3[0]*1500;
         System.out.println("Numero de lapices y cuadernos vendidos en enero y febrero: ");
        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 2; j++) {
                c[i][j] = 0;
                for (int k = 0; k < 2; k++) {
                    c[i][j] += a[i][k] * enerofebrero[k][j];//multiplica la cantidad de la promocion por las promociones vendidas
                }
                System.out.print(c[i][j] + " ");
            }
            System.out.println();
            System.out.println("total de cantidades de la tercera promocion " + totallapicesenero);
            System.out.println("total valor de la tercera promocion " + valortotalprom3enero);
            
        }
        System.out.println("Valor total  de lapices y cuadernos vendidos en enero y febrero: ");
        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 2; j++) {
                total[i][j] = 0;
                for (int k = 0; k < 2; k++) {
                    total[i][j] += c[i][k] * ventas[k][j];
                }
                System.out.print("$" + total[i][j] + " ");
            }
            System.out.println();
        }

        //el valor de las ventas mensuales 
        int enero = 0;
        int febrero = 0;

        for (int i = 0; i < 2; i++) {
            enero += total[i][0];

        }
        System.out.println("Total ventas enero: " + "$" + enero);
        for (int i = 0; i < 2; i++) {
            febrero += total[i][1];

        }
        System.out.println("Total ventas febrero: " + "$" + febrero);
        System.out.println("================================================================");

        
        
//marzo y abril
int totallapicesmarzo = marzoabril3[0]*b[0];
        int valortotalprom3marzo = marzoabril3[0]*1500;
        System.out.println("Numero de lapices y cuadernos vendidos en marzo y abril: ");
        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 2; j++) {
                c[i][j] = 0;
                for (int k = 0; k < 2; k++) {
                    c[i][j] += a[i][k] * marzoabril[k][j];//multiplica la cantidad de la promocion por las promociones vendidas
                }
                System.out.print(c[i][j] + " ");
            }
            System.out.println();
        }
        
        System.out.println("total de cantidades de la tercera promocion " + totallapicesmarzo);
            System.out.println("total valor de la tercera promocion " + valortotalprom3marzo);
            
        System.out.println("Valor total  de lapices y cuadernos vendidos en marzo y abril: ");
        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 2; j++) {
                total[i][j] = 0;
                for (int k = 0; k < 2; k++) {
                    total[i][j] += c[i][k] * ventas[k][j];
                }
                System.out.print("$" + total[i][j] + " ");
            }
            System.out.println();
        }

        //el valor de las ventas mensuales 
        int marzo = 0;
        int abril = 0;

        for (int i = 0; i < 2; i++) {
            marzo += total[i][0];

        }
        System.out.println("Total ventas marzo: " + "$" + marzo);
        for (int i = 0; i < 2; i++) {
            abril += total[i][1];

        }
        System.out.println("Total ventas abril: " + "$" + abril);
 System.out.println("================================================================");

        
        
//mayo y junio

int totallapicesmayo = mayojunio3[0]*b[0];
        int valortotalprom3mayo = mayojunio3[0]*1500;
        
        System.out.println("Numero de lapices y cuadernos vendidos en mayo y junio: ");
        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 2; j++) {
                c[i][j] = 0;
                for (int k = 0; k < 2; k++) {
                    c[i][j] += a[i][k] * mayojunio[k][j];//multiplica la cantidad de la promocion por las promociones vendidas
                }
                System.out.print(c[i][j] + " ");
            }
            System.out.println();
        }
        
                System.out.println("total de cantidades de la tercera promocion " + totallapicesmayo);
            System.out.println("total valor de la tercera promocion " + valortotalprom3mayo);
            
        System.out.println("Valor total  de lapices y cuadernos vendidos en mayo y junio: ");
        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 2; j++) {
                total[i][j] = 0;
                for (int k = 0; k < 2; k++) {
                    total[i][j] += c[i][k] * ventas[k][j];
                }
                System.out.print("$" + total[i][j] + " ");
            }
            System.out.println();
        }

        //el valor de las ventas mensuales 
        int mayo = 0;
        int junio = 0;

        for (int i = 0; i < 2; i++) {
            mayo += total[i][0];

        }
        System.out.println("Total ventas mayo: " + "$" + mayo);
        for (int i = 0; i < 2; i++) {
           junio += total[i][1];

        }
        System.out.println("Total ventas junio: " + "$" + junio);
        System.out.println("===========================================================================");



//julio y agosto
int totallapicesjulio = julioagosto3[0]*b[0];
        int valortotalprom3julio = julioagosto3[0]*1500;
        System.out.println("Numero de lapices y cuadernos vendidos en julio y agosto: ");
        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 2; j++) {
                c[i][j] = 0;
                for (int k = 0; k < 2; k++) {
                    c[i][j] += a[i][k] * julioagosto[k][j];//multiplica la cantidad de la promocion por las promociones vendidas
                }
                System.out.print(c[i][j] + " ");
            }
            System.out.println();
        }
        
               System.out.println("total de cantidades de la tercera promocion " + totallapicesjulio);
            System.out.println("total valor de la tercera promocion " + valortotalprom3julio);
        System.out.println("Valor total  de lapices y cuadernos vendidos en julio y agosto: ");
        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 2; j++) {
                total[i][j] = 0;
                for (int k = 0; k < 2; k++) {
                    total[i][j] += c[i][k] * ventas[k][j];
                }
                System.out.print("$" + total[i][j] + " ");
            }
            System.out.println();
        }

        //el valor de las ventas mensuales 
        int julio = 0;
        int agosto = 0;

        for (int i = 0; i < 2; i++) {
            julio += total[i][0];

        }
        System.out.println("Total ventas julio: " + "$" + julio);
        for (int i = 0; i < 2; i++) {
           agosto += total[i][1];

        }
        System.out.println("Total ventas agosto: " + "$" + agosto);
        System.out.println("===========================================================================");
        
        
        
        
        //septiembre y octubre
     
        System.out.println("Numero de lapices y cuadernos vendidos en septiembre y octubre: ");
        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 2; j++) {
                c[i][j] = 0;
                for (int k = 0; k < 2; k++) {
                    c[i][j] += a[i][k] * septiembreoctubre[k][j];//multiplica la cantidad de la promocion por las promociones vendidas
                }
                System.out.print(c[i][j] + " ");
            }
            System.out.println();
        }
        System.out.println("Valor total  de lapices y cuadernos vendidos en septiembre y octubre: ");
        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 2; j++) {
                total[i][j] = 0;
                for (int k = 0; k < 2; k++) {
                    total[i][j] += c[i][k] * ventas[k][j];
                }
                System.out.print("$" + total[i][j] + " ");
            }
            System.out.println();
        }

        //el valor de las ventas mensuales 
        int septiembre = 0;
        int octubre = 0;

        for (int i = 0; i < 2; i++) {
            septiembre += total[i][0];

        }
        System.out.println("Total ventas septiembre: " + "$" + septiembre);
        for (int i = 0; i < 2; i++) {
           octubre += total[i][1];

        }
        System.out.println("Total ventas octubre: " + "$" + octubre);
        System.out.println("===========================================================================");
        
        
        
        
        //noviembre y diciembre
        System.out.println("Numero de lapices y cuadernos vendidos en noviembre y diciembre: ");
        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 2; j++) {
                c[i][j] = 0;
                for (int k = 0; k < 2; k++) {
                    c[i][j] += a[i][k] * noviembrediciembre[k][j];//multiplica la cantidad de la promocion por las promociones vendidas
                }
                System.out.print(c[i][j] + " ");
            }
            System.out.println();
        }
        System.out.println("Valor total  de lapices y cuadernos vendidos en noviembre y diciembre: ");
        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 2; j++) {
                total[i][j] = 0;
                for (int k = 0; k < 2; k++) {
                    total[i][j] += c[i][k] * ventas[k][j];
                }
                System.out.print("$" + total[i][j] + " ");
            }
            System.out.println();
        }

        //el valor de las ventas mensuales 
        int noviembre = 0;
        int diciembre = 0;

        for (int i = 0; i < 2; i++) {
            noviembre += total[i][0];

        }
        System.out.println("Total ventas noviembre: " + "$" + noviembre);
        for (int i = 0; i < 2; i++) {
           diciembre += total[i][1];

        }
        System.out.println("Total ventas diciembre: " + "$" + diciembre);
        System.out.println("===========================================================================");
        
    }

}

