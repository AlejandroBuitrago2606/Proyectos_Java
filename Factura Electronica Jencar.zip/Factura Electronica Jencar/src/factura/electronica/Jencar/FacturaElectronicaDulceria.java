package factura.electronicaj.;

public class FacturaElectronicaPasadena {

    public static void main(String[] args) {
        System.out.println("===========================================================");
        System.out.println("\t\033[32m.::Distribuciones Jencar::.");
        System.out.println("\t\033[32mNit:900.300.333-5");
        System.out.println("\t\033[32mCel: 3164578914");
        System.out.println("\t\033[32mSogamoso - Boyaca");
        System.out.println("===========================================================");
        System.out.println("\033[34mproducto"+"\t\t\033[34mcantidad"+"\t\t\033[34mprecio");
        System.out.println("===========================================================");
        System.out.printf("%10s       %6d                  %8.2f\n","\033[33mFruticas caramelo",10,65813.00);
        System.out.printf("%10s     %6d                  %8.2f\n","\033[33mMordisqueta Cookies",10,66830.00);
        System.out.printf("%10s    %6d                  %8.2f\n","\033[33mMordisqueta maracuya",10,66830.00);
        System.out.printf("%10s         %6d                  %8.2f\n","\033[33mMenta Snow Mint",10,65309.00);
        System.out.printf("%10s            %6d                  %8.2f\n","\033[33mGrissly Aros",10,61421.00);
        System.out.printf("%10s       %6d                  %8.2f\n","\033[33mGalleta Wafer Muu",10,57137.00);
        System.out.println("==========================================================="); 
        System.out.println("\t\t\t\t\033[90mSubtotal: "+"$"+"\t\033[90m 383340.00");
        System.out.println("\t\t\t\t\033[90mIva: "+"$"+"\t\033[90m          72834.00");
        System.out.println("\t\t\t\t\033[90mTotal: "+"$"+"\t\033[90m 456174.00");
        System.out.println("===========================================================");
        System.out.println("\t\t\033[31m\"Gracias por su compra\"");
        System.out.println("===========================================================");
    
        }

}
