package evaluacion_poo;

import java.util.LinkedList;
import java.util.Scanner;

public class Principal {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        CuentaBancaria cuenta1 = new CuentaBancaria();
        int Opcion = 0;

        while (Opcion < 8){
        System.out.println("**********Opciones********");
        System.out.println("1. Agregar cuenta");
        System.out.println("2. Detalles de la cuenta");//x
        System.out.println("3. Consultar Saldo");
        System.out.println("4. Consignar");
        System.out.println("5. Retirar");//x
        System.out.println("6. Comparar Saldos");
        System.out.println("7. Transferir dinero a otra cuenta");
        System.out.println("8. Salir");

        System.out.println("selecciona una opcion");
        Opcion = sc.nextInt();
        cuenta1.Metodos(Opcion);

    }

}
}