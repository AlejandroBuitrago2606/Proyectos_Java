package evaluacion_poo;

import java.util.LinkedList;
import java.util.Scanner;
//String Nombres;
//    String Apellidos;
//    int NumerodeCuenta;
//    String tipodeCuenta;
//    double SaldoCuenta = 50000;

public class CuentaBancaria {

    LinkedList<String> Nombres = new LinkedList<>();
    LinkedList<String> Apellidos = new LinkedList<>();
    LinkedList<Integer> NumerodeCuenta = new LinkedList<>();
    LinkedList<String> Tipodecuenta = new LinkedList<>();
    LinkedList<Double> SaldodeCuenta = new LinkedList<>();

    public CuentaBancaria() {
    }

    public LinkedList<String> getNombres() {
        return Nombres;
    }

    public void setNombres(LinkedList<String> Nombres) {
        this.Nombres = Nombres;
    }

    public LinkedList<String> getApellidos() {
        return Apellidos;
    }

    public void setApellidos(LinkedList<String> Apellidos) {
        this.Apellidos = Apellidos;
    }

    public LinkedList<Integer> getNumerodeCuenta() {
        return NumerodeCuenta;
    }

    public void setNumerodeCuenta(LinkedList<Integer> NumerodeCuenta) {
        this.NumerodeCuenta = NumerodeCuenta;
    }

    public LinkedList<String> getTipodecuenta() {
        return Tipodecuenta;
    }

    public void setTipodecuenta(LinkedList<String> Tipodecuenta) {
        this.Tipodecuenta = Tipodecuenta;
    }

    public LinkedList<Double> getSaldodeCuenta() {
        return SaldodeCuenta;
    }

    public void setSaldodeCuenta(LinkedList<Double> SaldodeCuenta) {

        this.SaldodeCuenta = SaldodeCuenta;
    }

    public void Metodos(int opcion) {
        Scanner sc = new Scanner(System.in);

        if (opcion < 8) {
            switch (opcion) {
                case 1:
//agregar cuenta

                    System.out.println("Ingresa los Nombres");
                    String nombre = sc.nextLine();
                    Nombres.add(nombre);

                    System.out.println("Ingresa los apellidos");
                    String apellidos = sc.nextLine();
                    Apellidos.add(apellidos);

                    System.out.println("Ingresa el numero de cuenta");
                    int numerocuenta = sc.nextInt();
                    NumerodeCuenta.add(numerocuenta);

                    System.out.println("Ingresa el Tipo de cuenta");
                    String tipocuenta = sc.nextLine();
                    Tipodecuenta.add(tipocuenta);
                    sc.nextLine();

                    System.out.println("Ingresa el saldo de la cuenta");
                    double valorcuenta = sc.nextDouble();
                    double saldoinicial = valorcuenta + 50000;
                    SaldodeCuenta.add(saldoinicial);

                    System.out.println("La cuenta fue agregada con exito");

                    break;
                case 2:
                    //Listar
                    System.out.println("Ingresa el numero de cuenta: ");
                    int numcuenta = sc.nextInt();
                    int indice = Nombres.indexOf(numcuenta);

                    //se verifica que la cuenta se encuentra
                    System.out.println(
                            "\nNombres: " + Nombres.get(indice)
                            + "\nApellidos: " + Apellidos.get(indice)
                            + "\nNumero de Cuenta: " + NumerodeCuenta.get(indice)
                            + "\nTipo de Cuenta: " + Tipodecuenta.get(indice)
                            + "\nSaldo de la cuenta: " + SaldodeCuenta.get(indice));
                    System.out.println("Se a listado la cuenta");

                    break;

                case 3:
                    //consultar saldo
                    System.out.println("Ingrese el numero de cuenta: ");
                    int numcuenta1 = sc.nextInt();
                    int indice1 = NumerodeCuenta.indexOf(numcuenta1);

                    //se verifica que la cuenta se encuentra
                    if (NumerodeCuenta.contains(numcuenta1)) {
                        if (indice1 >= 0) {
                            System.out.println("Cuenta Bancaria No: " + NumerodeCuenta.get(indice1) + "\nSaldo de la cuenta: " + SaldodeCuenta.get(indice1));
                            System.out.println("La consulta fue realizada con exito");

                        }
                    } else {
                        System.out.println("La cuenta no esta registrada");
                    }

                    break;
                case 4:
                    //consignar
                    System.out.println("Ingresa el numero de cuenta a la que consignaras el valor");
                    int numcuenta2 = sc.nextInt();
                    int indice2 = NumerodeCuenta.indexOf(numcuenta2);

                    //se verifica que la cuenta se encuentra
                    if (NumerodeCuenta.contains(numcuenta2)) {
                        if (indice2 >= 0) {
                            System.out.println("Ingresa el monto a agregar");
                            double monto = sc.nextDouble();
                            SaldodeCuenta.add(indice2, SaldodeCuenta.get(indice2) + monto);
                            System.out.println("Cuenta Bancaria No: " + NumerodeCuenta.get(indice2) + "\nSaldo de la cuenta: " + SaldodeCuenta.get(indice2));
                            System.out.println("La consignacion se realizo con exito");
                        }
                    } else {
                        System.out.println("La cuenta no esta registrada");
                    }

                    break;

                case 5:
                    //Retirar
                    System.out.println("Ingresa el numero de cuenta a la que retiraras");
                    int numcuenta3 = sc.nextInt();
                    int indice3 = NumerodeCuenta.indexOf(numcuenta3);

                    //se verifica que la cuenta se encuentra
                    if (NumerodeCuenta.contains(numcuenta3)) {
                        if (indice3 >= 0) {
                            System.out.println("Cuenta Bancaria No: " + NumerodeCuenta.get(indice3) + "\nSaldo de la cuenta: " + SaldodeCuenta.get(indice3));
                            System.out.println("Ingresa el monto a retirar");
                            double retirar = sc.nextDouble();
                            if (retirar < SaldodeCuenta.get(indice3)) {
                                SaldodeCuenta.remove(SaldodeCuenta.get(indice3) - retirar);
                                System.out.println("Cuenta Bancaria No: " + NumerodeCuenta.get(indice3) + "\nSaldo de la cuenta: " + SaldodeCuenta.get(indice3));
                                System.out.println("El retiro fue realizado con exito");
                            } else {
                                System.out.println("No se puede realizar el retiro ¡¡la cantidad es mayor a lo que hay en saldo!!");
                            }

                        }
                    } else {
                        System.out.println("La cuenta no esta registrada ¡¡no le robes el dinero a tu abuelita :P!!");
                    }

                    break;
                case 6:
                    //comparar cuentas
                    System.out.println("Ingresa el numero de la primera cuenta a comparar: ");
                    int c1 = sc.nextInt();
                    System.out.println("Ingresa el numero de la segunda cuenta a comparar: ");
                    int c2 = sc.nextInt();
                    int indicecuenta1 = NumerodeCuenta.indexOf(c1);
                    int indicecuenta2 = NumerodeCuenta.indexOf(c2);

                    //se verifica que las cuentas se encuentran
                    if (NumerodeCuenta.contains(c1) && NumerodeCuenta.contains(c2)) {
                        boolean afirmacion = (SaldodeCuenta.get(indicecuenta1) >= SaldodeCuenta.get(indicecuenta2));
                        System.out.println("La comparacion es: " + afirmacion);
                    } else {
                        System.out.println("Las cuentas no estan registradas");
                    }

                    break;
                    
                    case 7:
                    //transferir
                        System.out.println("Ingresa el numero de la cuenta de origen: ");
                        int cuentaOrigen = sc.nextInt();
                        System.out.println("Ingresa el numero de la cuenta de destino: ");
                        int cuentadestino = sc.nextInt();
                        int indiceOrigen = NumerodeCuenta.indexOf(cuentaOrigen);
                        int indiceDestino = NumerodeCuenta.indexOf(cuentadestino);
                        System.out.println("Ingresa el valor a transferir");
                        double valor = sc.nextDouble();
                        
                        
                    break;

                default:
                    System.out.println("Opcion no valida");
            }

        }

    }
//public Transferir(){

}





