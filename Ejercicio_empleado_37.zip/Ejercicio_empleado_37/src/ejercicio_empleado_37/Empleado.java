package ejercicio_empleado_37;

import com.sun.source.tree.SwitchTree;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class Empleado {

    ArrayList<String> Documento = new ArrayList();
    ArrayList<Object> TipoDoc = new ArrayList();
    ArrayList<String> Nombre = new ArrayList();
    ArrayList<Integer> Edad = new ArrayList();
    ArrayList<String> Mail = new ArrayList();
    ArrayList<Integer> Salario = new ArrayList();

    public Empleado() {
    }

    public ArrayList<String> getDocumento() {
        return Documento;
    }

    public void setDocumento(ArrayList<String> Documento) {
        this.Documento = Documento;
    }

    public ArrayList<Object> getTipoDoc() {
        return TipoDoc;
    }

    public void setTipoDoc(ArrayList<Object> TipoDoc) {
        this.TipoDoc = TipoDoc;
    }

    public ArrayList<String> getNombre() {
        return Nombre;
    }

    public void setNombre(ArrayList<String> Nombre) {
        this.Nombre = Nombre;
    }

    public ArrayList<Integer> getEdad() {
        return Edad;
    }

    public void setEdad(ArrayList<Integer> Edad) {
        this.Edad = Edad;
    }

    public ArrayList<String> getMail() {
        return Mail;
    }

    public void setMail(ArrayList<String> Mail) {
        this.Mail = Mail;
    }

    public ArrayList<Integer> getSalario() {
        return Salario;
    }

    public void setSalario(ArrayList<Integer> Salario) {
        this.Salario = Salario;
    }

    public void MensajeSalario() {

        if (Salario.get(0) < 2600000) {

            JOptionPane.showMessageDialog(null, "SALARIO MENOR A DOS SALARIOS MINIMOS", "Mensaje", JOptionPane.WARNING_MESSAGE);

        } else {
            JOptionPane.showMessageDialog(null, "SALARIO NORMAL", "Mensaje", JOptionPane.INFORMATION_MESSAGE);
        }

    }

    public void MostrarDatos() {
        JOptionPane.showMessageDialog(null, "Documento: " + getDocumento()
                + "\nTipo de documento: " + getTipoDoc()
                + "\nNombre: " + getNombre()
                + "\nEdad: " + getEdad()
                + "\nEmail: " + getMail()
                + "\nSalario: " + getSalario()
        );
    }

    public void getFunciones(int Funciones) {

        switch (Funciones) {
            case 0:

                String documento = JOptionPane.showInputDialog("Ingresa el numero de documento: ");
                Documento.add(documento);
                String[] tipoDoc = {"Tarjeta Identidad", "Cedula", "Pasaporte"};
                Object tipD = JOptionPane.showInputDialog(null, "Selecciona el tipo de documento: ", "titulo", JOptionPane.PLAIN_MESSAGE, null, tipoDoc, "?");
                TipoDoc.add(tipD);
                String name = JOptionPane.showInputDialog("Ingresa el nombre: ");
                Nombre.add(name);
                int edad = Integer.parseInt(JOptionPane.showInputDialog("Ingresa la edad: "));
                Edad.add(edad);
                String email = JOptionPane.showInputDialog("Ingresa el email: ");
                Mail.add(email);
                int salario = Integer.parseInt(JOptionPane.showInputDialog("Ingresa el salario: "));
                Salario.add(salario);

                JOptionPane.showMessageDialog(null, "No. Documento: " + Documento.get(1) + "\nTipo de documento: " + TipoDoc.get(1) + "\nNombre: " + Nombre.get(1) + "\nEdad: " + Edad.get(1) + "\nEmail: " + Mail.get(1) + "\nSalario: " + Salario.get(1));

                JOptionPane.showMessageDialog(null, "No. Documentos: " + Documento + "\nTipos de documento: " + TipoDoc + "\nNombre: " + Nombre + "\nEdad: " + Edad + "\nEmail: " + Mail + "\nSalario: " + Salario);
                break;

            case 1:
                String buscar;
                buscar = JOptionPane.showInputDialog("ingresa el nombre a buscar: ");
                Nombre.contains(buscar);
                JOptionPane.showMessageDialog(null, buscar);

                break;

            case 2:
                String nam = JOptionPane.showInputDialog("Ingresa el nombre: ");
                int indice = Nombre.indexOf(nam);
                if (indice >= 0) {

                    Documento.remove(indice);
                    TipoDoc.remove(indice);
                    Nombre.remove(indice);
                    Edad.remove(indice);
                    Mail.remove(indice);
                    Salario.remove(indice);

                    JOptionPane.showMessageDialog(null, "No. Documentos: " + Documento + "\nTipos de documento: " + TipoDoc + "\nNombre: " + Nombre + "\nEdad: " + Edad + "\nEmail: " + Mail + "\nSalario: " + Salario);

                }

                break;

            default:
                throw new AssertionError();

        }

    }

}
