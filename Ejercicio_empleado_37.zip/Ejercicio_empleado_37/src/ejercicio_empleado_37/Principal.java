package ejercicio_empleado_37;

import java.awt.Image;
import javax.swing.ImageIcon;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class Principal extends Empleado {

    public static void main(String[] args) {

        Empleado empl = new Empleado();

        String doc = JOptionPane.showInputDialog("ingresa el numero de documento");
        empl.Documento.add(doc);

        String[] tipoDoc = {"Tarjeta Identidad", "Cedula", "Pasaporte"};

        Object tipD = JOptionPane.showInputDialog(null, "Selecciona el tipo de documento: ", "titulo", JOptionPane.PLAIN_MESSAGE, null, tipoDoc, "?");
        empl.TipoDoc.add(tipD);

        String nombre = JOptionPane.showInputDialog("ingresa el nombre");

        empl.Nombre.add(nombre);

        int edad = Integer.parseInt(JOptionPane.showInputDialog("ingresa la edad"));

        empl.Edad.add(edad);

        String mail = JOptionPane.showInputDialog("ingresa el E-mail");

        empl.Mail.add(mail);

        int salario = Integer.parseInt(JOptionPane.showInputDialog("ingresa el salario"));

        empl.Salario.add(salario);

//Mostrar datos y comparacion de salario 
        empl.MensajeSalario();

        empl.MostrarDatos();

        String[] Opciones = {"Agregar", "Buscar", "Eliminar"};
        int indice = JOptionPane.showOptionDialog(null, "Selecciona una operacion", "Mensaje", JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null, Opciones, Opciones[0]);
        empl.getFunciones(indice);
    }

//        public static void mostrarimagen (String ruta ) {
//        ImageIcon icon =new ImageIcon("src/icons/" + ruta);
//        Image img = icon.getImage();
//        cambiar tamaño de una imagen:  Image newimg = img.getScaledInstance(300,300,java.awt.Image.SCALE_SMOOTH);
//        mostrar imagen actualizada con las nuevas caracteriticas:// icon = new ImageIcon(newimg);
//        JOptionPane.showMessageDialog(null, "Hola", "", JOptionPane.PLAIN_MESSAGE, icon);
//        System.out.println("");
}
