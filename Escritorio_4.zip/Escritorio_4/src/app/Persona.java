package app;

import java.util.ArrayList;

public abstract class Persona {

    ArrayList di;
    ArrayList nombre;
    ArrayList celular;

    public Persona(ArrayList di, ArrayList nombre, ArrayList celular) {
        this.di = di;
        this.nombre = nombre;
        this.celular = celular;
    }

    public ArrayList getDi() {
        return di;
    }

    public void setDi(ArrayList di) {
        this.di = di;
    }

    public ArrayList getNombre() {
        return nombre;
    }

    public void setNombre(ArrayList nombre) {
        this.nombre = nombre;
    }

    public ArrayList getCelular() {
        return celular;
    }

    public void setCelular(ArrayList celular) {
        this.celular = celular;
    }

    public abstract void GuardarDi(String dis);

    public abstract void GuardarNombre(String nombres);

    public abstract void GuardarCelular(String celular);

    public abstract void EliminarDi(String dis);

    public abstract void EliminarNombre(String nombres);

    public abstract void EliminarCelular(String celular);

    public abstract String BuscarDi(String dis);

    public abstract String BuscarNombre(String nombres);

    public abstract String BuscarCelular(String celular);
}
