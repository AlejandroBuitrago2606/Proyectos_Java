package app;

import java.util.ArrayList;

public class Aprendiz extends Persona {

    public Aprendiz(ArrayList di, ArrayList nombre, ArrayList celular) {
        super(di, nombre, celular);
    }

    @Override
    public void GuardarDi(String dis) {
        super.di.add(dis);
    }

    @Override
    public void GuardarNombre(String nombres) {
        super.nombre.add(nombres);
    }

    @Override
    public void GuardarCelular(String celular) {
        super.nombre.add(celular);
    }

    @Override
    public void EliminarDi(String dis) {
        super.di.remove(dis);
    }

    @Override
    public void EliminarNombre(String nombres) {
        super.nombre.remove(nombres);
    }

    @Override
    public void EliminarCelular(String celular) {
        super.celular.remove(celular);
    }

    @Override
    public String BuscarDi(String dis) {
    String buscardi = "";
    
        if (super.di.contains(dis)==true) {
            buscardi = super.di.get(super.di.indexOf(dis)).toString();
        } else {
            buscardi = "No existe";
        }
        return buscardi;
    }

    @Override
    public String BuscarNombre(String nombres) {
    String buscarnombre = "";
    
        if (super.nombre.contains(nombres)==true) {
            buscarnombre = super.nombre.get(super.nombre.indexOf(nombres)).toString();
        } else {
            buscarnombre = "No existe";
        }
        return buscarnombre;
    }

    @Override
    public String BuscarCelular(String celular) {
    String buscarcelular = "";
    
        if (super.celular.contains(celular)==true) {
            buscarcelular = super.celular.get(super.celular.indexOf(celular)).toString();
        } else {
            buscarcelular = "No existe";
        }
        return buscarcelular;
//    }

}
