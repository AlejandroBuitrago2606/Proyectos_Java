package practica_31;

/*
La empresa Holcim, requiere liquidar la nomina de sus empleados
por lo que necesita un programa que calcule el salario total, 
con el salario pagado por horas y las horas trabajadas, 
tener en cuenta todos los requisitos de ley, es decir, pago pensiones
 */
public class Nomina {

    private final int Minimo = 1300000;
    private final double Auxilio = 162000;

    protected double salarioHora;
    protected int HorasTrabajadas;

    public Nomina(double salarioHora, int HorasTrabajadas) {
        this.salarioHora = salarioHora;
        this.HorasTrabajadas = HorasTrabajadas;
    }

    public double getSalarioHora() {
        return salarioHora;
    }

    public void setSalarioHora(double salarioHora) {
        this.salarioHora = salarioHora;
    }

    public int getHorasTrabajadas() {
        return HorasTrabajadas;
    }

    public void setHorasTrabajadas(int HorasTrabajadas) {
        this.HorasTrabajadas = HorasTrabajadas;
    }

    protected double getSalarioBruto() {
        return salarioHora * HorasTrabajadas;
    }

    protected double getDescuentoEPS() {
        return getSalarioBruto() * 0.04;
    }

    protected double getDescuentoAFP() {
        return getSalarioBruto() * 0.04;
    }

    protected double getDescuentoRiesgos() {
        return getSalarioBruto() * 0.0522;
    }

    public double getSalarioNeto() {
        double salarioBruto = getSalarioBruto();
        double auxilioTransp = 0;
        if (salarioBruto <= 2600000) {
            auxilioTransp = Auxilio;
        }
        return (getSalarioBruto() - getDescuentoEPS() - getDescuentoAFP() - getDescuentoRiesgos()) + auxilioTransp;
    }

    @Override
    public String toString() {
        return "Salario Bruto: $" + String.format("%.2f", getSalarioBruto())
                + "\nDescuento AFP: $" + String.format("%.2f", getDescuentoAFP())
                + "\nDescuento EPS: $" + String.format("%.2f", getDescuentoEPS())
                + "\nDescuento Riesgos: $" + String.format("%.2f", getDescuentoRiesgos())
                + "\nAuxilio Transporte: $" + ((getSalarioBruto() > 2600000) ? 0 : Auxilio) + "\n"
                + "\n Total salario con Descuentos: $" + String.format("%.2f", getSalarioNeto()); 
    }

}
