
package practica_31;

import java.util.Scanner;

public class Principal {

    public static void main(String[] args) {
      
        Scanner sc = new Scanner (System.in);
        System.out.println("Dijite el salario hora: ");
        double salarioHora = sc.nextDouble();
        System.out.println("Dijite la horas elaboradas: ");
        int horas = sc.nextInt();
        Nomina nomina = new Nomina(salarioHora,horas);
        System.out.println("Nomina: " + nomina);
    }
    
}
