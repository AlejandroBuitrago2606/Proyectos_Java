package practica_23;

import java.util.Scanner;

public class Practica_23 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int m, n;
        System.out.println("digite el numero de filas");
        m = sc.nextInt();
        System.out.println("digite el numero de columnas");
        n = sc.nextInt();
        //operaciones de matrices: suma, resta, multiplicacion
        //Declarar las matrices

        int[][] a = new int[m][n];
        int[][] b = new int[m][n];
        int[][] suma = new int[m][n];
        int[][] resta = new int[m][n];
        int[][] multi = new int[m][n];

        //Ingreso dw datos a la matriz "a"
        System.out.println("Ingrese los elementos de la matriz a");
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                a[i][j] = sc.nextInt();

            }

            //Ingreso dw datos a la matriz "b"
            System.out.println("Ingrese los elementos de la matriz b");
            for (i = 0; i < m; i++) {
                for (int j = 0; j < n; j++) {
                    b[i][j] = sc.nextInt();

                }
            }

            //Suma de matrices 
            for (i = 0; i < m; i++) {
                for (int j = 0; j < n; j++) {
                    suma[i][j] = a[i][j] + b[i][j];

                }
            }

            //Resta de matrices 
            for (i = 0; i < m; i++) {
                for (int j = 0; j < n; j++) {
                    resta[i][j] = a[i][j] - b[i][j];

                }
            }

            //Multip de matrices 
            for (i = 0; i < m; i++) {
                for (int j = 0; j < n; j++) {
                    for (int k = 0; k < n; k++) {
                        multi[i][j] += a[i][k] * b[k][j];
                    }

                }

            }
            //Mostrar datos suma
            System.out.println("suma de matrices: ");
            for (i = 0; i < m; i++) {
                for (int j = 0; j < n; j++) {
                    System.out.println(suma[i][j] + " ");
                }
                System.out.println();
            }
            
            //Mostrar datos resta
            System.out.println("resta de matrices: ");
            for (i = 0; i < m; i++) {
                for (int j = 0; j < n; j++) {
                    System.out.println(resta[i][j] + " ");
                }
                System.out.println();
            }
            
            //Mostrar datos Multiplicacion
            System.out.println("Multiplicacion de matrices: ");
            for (i = 0; i < m; i++) {
                for (int j = 0; j < n; j++) {
                    System.out.println(multi[i][j] + " ");
                }
                System.out.println();
            }

        }
        
    }
}





double valorventasfebrero = 13370 * cantpromofebrero;
System.out.println("Total de ventas del mes de febrero $" + Math.round(valorventasfebrero));
