package app;

public class Mascota {
String nombre;
String raza;
int edad;
String color;
Double peso;
}
