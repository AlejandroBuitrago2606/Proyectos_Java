package app;

import java.util.Scanner;

public class Principal {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Mascota mas = new Mascota();//clase "nombreclase" = new clase();
        System.out.println("Dijite el nombre de la mascota");
        mas.nombre = sc.nextLine();
        System.out.println("Dijite la raza de la mascota");
        mas.raza = sc.nextLine();
        System.out.println("Dijite la edad de la mascota");
        mas.edad = sc.nextInt();
        System.out.println("Dijite el color de la mascota");
        mas.color = sc.next();
        System.out.println("Dijite el peso de la mascota");
        mas.peso = sc.nextDouble();
        
        //Impresion de datos
        Mascota mas1 = new Mascota();
        System.out.println("Dijite el nombre de la mascota");
        mas1.nombre = sc.next();
        System.out.println("Dijite la raza de la mascota");
        mas1.raza = sc.next();
        System.out.println("Dijite la edad de la mascota");
        mas1.edad = sc.nextInt();
        System.out.println("Dijite el color de la mascota");
        mas1.color = sc.next();
        System.out.println("Dijite el peso de la mascota");
        mas1.peso = sc.nextDouble();
        
        System.out.println("Nombre: " + mas1.nombre);
        System.out.println("Raza: " + mas1.raza);
        System.out.println("Edad: " + mas1.edad);
        System.out.println("Color: " + mas1.color);
        System.out.println("Peso: " + mas1.peso);
        
        
        
    }
}
