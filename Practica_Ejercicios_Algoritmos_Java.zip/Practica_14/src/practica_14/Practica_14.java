
package practica_14;

import java.util.Scanner;

public class Practica_14 {

    public static void main(String[] args) {   
    Scanner sc = new Scanner(System.in);
        System.out.println("Dijite un numero");
        int ed = sc.nextInt();
        
        
    }
    
}
