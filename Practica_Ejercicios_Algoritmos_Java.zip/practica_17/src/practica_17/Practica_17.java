package practica_17;

import java.util.Arrays;

public class Practica_17 {

    public static void main(String[] args) {
        
        //array
        int numeros[];
        numeros = new int[4];
        numeros[0] = 1;
        numeros[1] = 2;
        numeros[2] = 3;
        numeros[3] = 4;
        System.out.println("numeros=[" + numeros[0] + "]");
        System.out.println("numeros=[" + numeros[1] + "]");
        System.out.println("numeros=[" + numeros[2] + "]");
        System.out.println("numeros=[" + numeros[3] + "]");

        String[] deportes = {
            "futbol", "natacion", "baloncesto", "beisbol"
        };
        System.out.println(deportes[0]);
        System.out.println(deportes[1]);
        System.out.println(deportes[2]);
        System.out.println(deportes[3]);

        
        int[] dijitos = {4, 0, 2, 1, 6, 5};
        System.out.println("Arreglo original " + Arrays.toString(dijitos));
        Arrays.sort(dijitos);//Arrays.sort = Metodo de ordenacion de arrays
        System.out.println("Arreglo ordenado " + Arrays.toString(dijitos));

        int[] d1 = {4, 0, 2, 1, 6, 5};
        int[] d2 = {4, 0, 2, 1, 6, 5};
        int[] d3 = {6, 0, 1, 2, 4, 5};
        boolean resultado = Arrays.equals(d1, d2);
        System.out.println("Los arreglos d1 y d2 son iguales??? " + resultado);
        resultado = Arrays.equals(d2, d3);// comparar arrays
        System.out.println("Los arreglos d2 y d3 son iguales??? " + resultado);
        
        double [] notas = new double [5];
        Arrays.fill(notas, 4.5);//Arrays.fill = llenar array
        System.out.println("Array lleno" + Arrays.toString(notas));
        
        double [] compras = {12000,15000,25000,32000};
        double [] copiacompras = Arrays.copyOf(compras,compras.length);//Arrays.copyOf = copiar array
        System.out.println("copia del array: " + Arrays.toString(copiacompras));
    
    
    
    
    
    
    
    
    
    }

}
