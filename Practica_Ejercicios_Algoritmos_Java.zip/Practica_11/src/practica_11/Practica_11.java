package practica_11;

import java.util.Scanner;

public class Practica_11 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Ingrese el numero de establecimientos para renovar: ");
        int numeroEstablecimientos = sc.nextInt();

        //Bucle para iterar cada establecimiento
        int i = 1;
        while (i <= numeroEstablecimientos) {
            //Solicitar datos de la empresa
            System.out.println(".::Establecimiento" + i + "::.");
            System.out.println("Dijite el Nit de la empresa: ");
            String nit = sc.next();
            System.out.println("Dijite el nombre de la empresa: ");
            String nombre = sc.next();
            System.out.println("Dijite la fecha de la matricula: ");
            String fechaMatricula = sc.next();
            System.out.println("Dijite la fecha de renovacion: ");
            String fecharenovacion = sc.next();
            System.out.println("Dijite el valor de la renovacion: ");
            double valorRenovacion = sc.nextDouble();
            //Mostramos los resultados
            System.out.println("Nit: " + nit);
            System.out.println("Nombre Empresa: " + nombre);
            System.out.println("Fecha Matricula: " + fechaMatricula);
            System.out.println("Fecha Renovacion: " + fecharenovacion);
            System.out.println("Valor Renovacion: " + valorRenovacion);
            i++;
        }//FIN while 1

    }

}
