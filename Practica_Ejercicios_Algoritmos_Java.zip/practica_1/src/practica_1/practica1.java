package practica_1;

/**
 *
 * @author SENA
 */
public class practica1 {
    public static void main(String[] args) {
        System.out.println("hola mundo");
        System.out.println("Mi nombre es: " + " Yuber"+"\nmi apellido es: "+"Gonzalez");
        
    }
    }
