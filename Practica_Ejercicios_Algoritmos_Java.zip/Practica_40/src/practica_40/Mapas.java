package practica_40;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;

public class Mapas {

    public static void main(String[] args) {

        HashMap<String, String> listaAprendices = new HashMap<String, String>();
        Scanner sc = new Scanner(System.in);

    }

    public static void guardarAprendiz(String di, String nombre, HashMap<String, String> listaAprendices) {
        if (listaAprendices.containsKey(di)) {
            System.out.println("El aprendiz ya existe...!!!");

        } else {
            listaAprendices.put(di, nombre);

        }

    }

    public static void ModificarAprendiz(String di, String nombre, HashMap<String, String> listaAprendices) {

        Scanner sc = new Scanner(System.in);
        if (listaAprendices.containsKey(di)) {
            System.out.println("Dijite el nombre del aprendiz: ");
            listaAprendices.put(di, nombre);

        } else {
            System.out.println("El aprendiz no existe: ");

        }
    }

    public static void mostrarAprendices(String di, String nombre, HashMap<String, String> listaAprendices) {
    String clave;
      //  Iterator <String> nombre = listaAprendices.keySet().iterator();
        System.out.println("Lista Aprendices");
        while (nombre.hasNext()) {            
        clave = nombre.next();
            System.out.println(clave + " - " + listaAprendices.get(clave));
           
        }
        
    }
    
    
}
