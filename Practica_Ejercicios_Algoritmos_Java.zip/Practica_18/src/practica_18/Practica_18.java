package practica_18;

import java.util.Scanner;

public class Practica_18 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Dijite la cantidad de registros a dijitar: ");
        int registros = sc.nextInt();
        String [] nombre = new String[registros];
        double[] salario = new double[registros];

        for (int i = 0; i <= registros; i++) {
            System.out.println("dijite el nombre del aprendiz" + (i + 1) + ":");
            nombre[i] = sc.next();
            System.out.println("dijite el salario");
            salario[i] = sc.nextDouble();
            
           
 
        }
 for (int i = 0; i < registros; i++) {
                System.out.println("aprendiz No" + (i+1) + ": " + nombre[i]);
                System.out.println("salario: " + salario[i]);
            }
    }

}
