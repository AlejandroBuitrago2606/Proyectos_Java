package practica_28;

import javax.swing.JOptionPane;

public class Principal {

    public static void main(String[] args) {
        Object[] tipo = {"cedula", "Cedula Extranjeria", "Pasaporte"};
        Object combox = JOptionPane.showInputDialog(null, "Seleccione el tipo de documento", "Elegir", JOptionPane.QUESTION_MESSAGE, null, tipo, tipo[0]);
        JOptionPane.showInputDialog(null, "Dijite el numero de cedula: ");
        JOptionPane.showInputDialog("Dijite el nombre del empleado: ");
        Object[] cargo = {"Gerente" , "Profesional" , "Auxiliar administrativo" , "Servicios generales"};
        Object comboxcargo = JOptionPane.showInputDialog(null, "Seleccione el cargo", "Elegir", JOptionPane.QUESTION_MESSAGE, null, cargo, cargo[0]);
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    }

}
