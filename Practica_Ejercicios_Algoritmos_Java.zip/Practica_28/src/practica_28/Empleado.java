package practica_28;

//Metodos
public class Empleado {

    private int id;
    private Object tipodoc;
    private String cedula;
    private String nombre;
    private Object cargo;
    private double salario;
    private double pension;
    private double salud;
    private double riesgos;

//Constructor
    public Empleado(int id, Object tipodoc, String cedula, String nombre, Object cargo, double salario, double pension, double salud, double riesgos) {
        this.id = id;
        this.tipodoc = tipodoc;
        this.cedula = cedula;
        this.nombre = nombre;
        this.cargo = cargo;
        this.salario = salario;
        this.pension = pension;
        this.salud = salud;
        this.riesgos = riesgos;
    }

    //Metodos de acceso
    //es para almacenar y mostrar los datos 'set' y 'get'
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Object getTipodoc() {
        return tipodoc;
    }

    public void setTipodoc(Object tipodoc) {
        this.tipodoc = tipodoc;
    }

    public String getCedula() {
        return cedula;
    }

    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Object getCargo() {
        return cargo;
    }

    public void setCargo(Object cargo) {
        this.cargo = cargo;
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }

    public double getPension() {
        return pension;
    }

    public void setPension(double pension) {
        this.pension = pension;
    }

    public double getSalud() {
        return salud;
    }

    public void setSalud(double salud) {
        this.salud = salud;
    }

    public double getRiesgos() {
        return riesgos;
    }

    public void setRiesgos(double riesgos) {
        this.riesgos = riesgos;
    }

    //Metodos de calculo
    public double calcularpension(){
        return salario * pension;
    }
    
        public double calcularSalud(){
        return salario * salud;
    }
    
        public double calcularRiesgos(){
        return salario * riesgos;
    }
    
        public double salariototal(){
        return salario - calcularpension() - calcularSalud() - calcularRiesgos();
    }

    @Override
    public String toString() {
        return "Empleado{" + "id=" + id + ", tipodoc=" + tipodoc + ", cedula=" + cedula + ", nombre=" + nombre + ", cargo=" + cargo + ", salario=" + salario + ", pension=" + pension + ", salud=" + salud + ", riesgos=" + riesgos + '}';
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
