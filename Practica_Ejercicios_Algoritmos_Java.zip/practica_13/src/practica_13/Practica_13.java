package practica_13;

import java.util.Scanner;

public class Practica_13 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Dijite un numero");
        int numero = sc.nextInt();
        System.out.println("Dijite otro numero");
        int numer = sc.nextInt();
        int resultado = suma(numero,numer);
        System.out.println("resultado: " + resultado);

    }

    static int suma(int num1, int num2) {
        return num1 + num2;
    }
}
