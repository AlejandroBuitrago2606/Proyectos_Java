package practica_2;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class Practica_2 {

    public static void main(String[] args) {
        /*
        FORMATO DE TEXTO 
        1. Salida formateada printf
        2. Sintaxis
          printf(String formato, Objeto..datos);
        3. Sintaxis para los especificadores de formato
        %[posicion datos][indicador de formato][ancho].[precision]caracter de
        4. Salida formateada para numeros
        5. d Numero entero de base decimal
        6. f Numero real con punto "1.1(cantidad numeros.cantidad de decimales)"
        7. E,e Numero real con notacion cientifica
        8. X,x Numero entero en base
        9.  s. String en Miniscula = cantidad de espacios de izquierda a derecha
        10. S String en Mayuscula = cantidad de espacios de izquierda a derecha
        11. C/c "Caracter" Unicode
        12. los numeros negativos se escriben entre parentesis
        13. "," Separador decimal
        14. + Mostrar signo + en numero positivo
        15. Rellenar con ceros
        //  /n = salto de linea
        //  /t = tabulador
        //  \\ = diagonal inversa
        //  \' = comilla sencilla
        //  \" = comilla doble
        //  libreria "date" = fecha
         */
        System.out.println("=======================================");
        System.out.println("\t.::Paladar oriental::.");
        System.out.println("\tNit:900.300.333-5");
        System.out.println("\tCel: 3164578914");
        System.out.println("\tNobsa - Boyaca");
        System.out.println("=======================================");
        System.out.println("Producto" + "\tCantidad" + "\tPrecio");
        System.out.println("=======================================");
        System.out.printf("%10s    %6d     %8.2f\n", "Pechuga plancha", 1, 29000.00);
        System.out.printf("%10s    %6d     %8.2f\n", "Ensalada con soya", 1, 30000.00);
        System.out.printf("%10s      %6d     %8.2f\n", "Onigiri", 1, 35000.00);
        System.out.println("=======================================");
        System.out.println("\t\tSubtotal: " + "$" + "   94000.00");
        System.out.println("\t\tIva: " + "$" + "        17850.00");
        System.out.println("\t\tTotal: " + "$" + "     111860.00");
        System.out.println("=======================================");
        System.out.println("\t\"gracias por su compra\"");
        System.out.println("=======================================");
        System.out.println("///////////////////////////////////////");

        System.out.printf("%b%n", true);
        System.out.printf("\033[32m%B%n", 6.3);
        System.out.printf("%b%n", "Bienvenidos ADSO Manana");
        System.out.printf("%s%n", "sena");
        System.out.printf("%S%n", "sena");
        System.out.printf("%20s%n", "sena");
        System.out.printf("%-10s %n", "sena");
        System.out.printf("%3.8s %n", "sena");
        System.out.printf("%c%n", 'c');
        System.out.printf("%C%n", 'c');
        System.out.printf("Entero simple: %d%n", 32500);
        System.out.printf(Locale.US, "$%,d%n", 32500);
        System.out.printf(Locale.ROOT, "$%,d%n", 32500);
        System.out.printf("Entero simple: %d%n", 32500);
        System.out.printf("%5.2f%n", 32500.7698);

//formato fecha
        Date dia = new Date();
        System.out.println("fecha y hora: " + new SimpleDateFormat("dd/mm/yyyy hh:mm:ss").format(dia));
        System.out.printf("Hora: %tT%n", dia);
        System.out.printf("hora: %tH%n Minutos: %tM%n Segundos: %tS%n", dia, dia, dia);
        System.out.printf("%1$tH: %1$tM %1$tS %1$tp %1$tL %1$tN %1$tz %n", dia);
        System.out.printf("Fecha: %1$td %1$tm %1$ty %n", dia);
        System.out.printf(String.format("Adso Maniana,%s", "Sena CIMM"));
        System.out.printf(String.format("Adso Maniana,%s:%s.%S", " ", " ", " "));

        double numero = 789.123456789;
        System.out.printf(numero + "=%.3f%n", numero);
        System.out.printf(numero + "=%.4f%n", numero);
        System.out.printf(numero + "=%09.2f%n", numero);
        System.out.printf(numero + "=%7.1ehf%n", numero);
        System.out.printf(numero + "=%7.3ef%n", numero);
    }

}
