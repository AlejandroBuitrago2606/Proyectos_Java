package Televisor;

import java.util.Scanner;
import javax.swing.JOptionPane;

public class Principal {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Televisor tv = new Televisor();

        System.out.println("Ingresa las propiedades del Televisor 1: ");

       // int id = sc.nextInt();
        tv.setId( Integer.parseInt(JOptionPane.showInputDialog("Id: ")));

        System.out.println("Marca: ");
        tv.setMarca ( JOptionPane.showInputDialog("Marca: "));

        System.out.println("Smart Tv");
        String smart = sc.next();
        tv.setSmartTV(smart);

        System.out.println("Resolucion: ");
        String r = sc.next();
        tv.setResolucion(r);

        System.out.println("Tipo de pantalla: ");
        String tipopantalla = sc.next();
        tv.setTipopantalla(tipopantalla);

        System.out.println("Garantia: ");
        String garantia = sc.next();
        tv.setGarantia(garantia);

        System.out.println("Precio: ");
        double precio = sc.nextDouble();
        tv.setPrecio(precio);

        JOptionPane.showMessageDialog(null, "Propiedades del Televisor 1: "
                + "\nId: " + tv.getId()
                + "\nMarca: " + tv.getMarca()
                + "\nSmart Tv: " + tv.getSmartTV()
                + "\nResolucion: " + tv.getResolucion()
                + "\nTipo de pantalla: " + tv.getTipopantalla()
                + "\nGarantia: " + tv.getGarantia()
                + "\nPrecio: " + tv.getPrecio());
        
        
        
        
        Televisor tv2 = new Televisor();

        System.out.println("Ingresa las propiedades del Televisor 2: ");

        System.out.println("Id: ");
        int id2 = sc.nextInt();
        tv2.setId(id2);

        System.out.println("Marca: ");
        String marca2 = sc.next();
        tv2.setMarca(marca2);

        System.out.println("Smart Tv");
        String smart2 = sc.next();
        tv2.setSmartTV(smart);

        System.out.println("Resolucion: ");
        String r2 = sc.next();
        tv2.setResolucion(r2);

        System.out.println("Tipo de pantalla: ");
        String tipopantalla2 = sc.next();
        tv2.setTipopantalla(tipopantalla2);

        System.out.println("Garantia: ");
        String garantia2 = sc.next();
        tv2.setGarantia(garantia2);

        System.out.println("Precio: ");
        double precio2 = sc.nextDouble();
        tv2.setPrecio(precio2);

        JOptionPane.showMessageDialog(null, "Propiedades del Televisor: "
                + "\nId: " + tv2.getId()
                + "\nMarca: " + tv2.getMarca()
                + "\nSmart Tv: " + tv2.getSmartTV()
                + "\nResolucion: " + tv2.getResolucion()
                + "\nTipo de pantalla: " + tv2.getTipopantalla()
                + "\nGarantia: " + tv2.getGarantia()
                + "\nPrecio: " + tv2.getPrecio());
        
        

    }

}
