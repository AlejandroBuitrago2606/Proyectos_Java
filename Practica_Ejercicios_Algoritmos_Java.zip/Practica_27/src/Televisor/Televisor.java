package Televisor;

public class Televisor {

    private int id;
    private String marca;
    private String SmartTV;
    private String resolucion;
    private String tipopantalla;
    private String garantia;
    private double precio;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getSmartTV() {
        return SmartTV;
    }

    public void setSmartTV(String SmartTV) {
        this.SmartTV = SmartTV;
    }

    public String getResolucion() {
        return resolucion;
    }

    public void setResolucion(String resolucion) {
        this.resolucion = resolucion;
    }

    public String getTipopantalla() {
        return tipopantalla;
    }

    public void setTipopantalla(String tipopantalla) {
        this.tipopantalla = tipopantalla;
    }

    public String getGarantia() {
        return garantia;
    }

    public void setGarantia(String garantia) {
        this.garantia = garantia;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }
    
    
    
}
