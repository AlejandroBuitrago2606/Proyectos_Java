package App;

import java.util.Scanner;

public class principal {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
       /*
        System.out.println("Datos del aprendiz No 1: ");
        System.out.println("Id: ");
        int id = sc.nextInt();
        
        System.out.println("Cedula: ");
        String cedula = sc.next();
       

        System.out.println("Nombre: ");
        String nombre = sc.next();
        

        System.out.println("Email: ");
        String email = sc.next();
        

        System.out.println("Celular: ");
        String celular = sc.next();
       

        System.out.println("Ciudad");
        String ciudad = sc.next();
     
         Aprendiz ap = new Aprendiz( id, cedula , nombre , email, celular, ciudad);
        System.out.println("Id: " + ap.getId()
                + "\nCedula: " + ap.getCedula()
                + "\nNombre: " + ap.getNombre()
                + "\nEmail: " + ap.getEmail()
                + "\nCelular: " +ap.getCelular()
                + "\nCiudad: " + ap.getCiudad());
        */
        
        Aprendiz ap = new Aprendiz( id, cedula , nombre , email, celular, ciudad);
        System.out.println("Datos del Aprendiz No 2: ");
        System.out.println("******************************");
        
        System.out.println("Id: ");
        int id = sc.nextInt();

        System.out.println("Cedula: ");
        String cedula = sc.next();

        System.out.println("Nombre: ");
        String nombre = sc.next();

        System.out.println("Email: ");
        String email = sc.next();

        System.out.println("Celular: ");
        String celular = sc.next();

        System.out.println("Ciudad");
        String ciudad = sc.next();
        
         
        

        //constructor
        /*
    Primer metodo que se ejecuta al realizar la instancia de un objeto
    Metodo especial a traves del cual podemos crear los objetos
    de la clase
         */
    }

}
