
package Maleta;
import javax.swing.JOptionPane;
public class Principal {

    public static void main(String[] args) {
       Maleta m = new Maleta();
       JOptionPane.showMessageDialog(null, "Maleta 1");
       m.setMarca(JOptionPane.showInputDialog("Marca: "));
       m.setColor(JOptionPane.showInputDialog("Color: "));
       m.setReferencia(JOptionPane.showInputDialog("Referencia: "));
       m.setPeso(Integer.parseInt(JOptionPane.showInputDialog("Peso: ")));
       m.setDimensiones(Integer.parseInt(JOptionPane.showInputDialog("Dimensiones: ")));
       
        JOptionPane.showMessageDialog(null, "Maleta 1");
        JOptionPane.showMessageDialog(null,"Marca: " + m.getMarca() + "\nColor: " + m.getColor() + "\nReferencia: " + m.getReferencia() + "\nPeso: "  + m.getPeso() + "\nDimensiones: " + m.getDimensiones());
       
        
        Maleta m2 = new Maleta();
       JOptionPane.showMessageDialog(null, "Maleta 2");
       m2.setMarca(JOptionPane.showInputDialog("Marca: "));
       m2.setColor(JOptionPane.showInputDialog("Color: "));
       m2.setReferencia(JOptionPane.showInputDialog("Referencia: "));
       m2.setPeso(Integer.parseInt(JOptionPane.showInputDialog("Peso: ")));
       m2.setDimensiones(Integer.parseInt(JOptionPane.showInputDialog("Dimensiones: ")));
       
        JOptionPane.showMessageDialog(null, "Maleta 2");
        JOptionPane.showMessageDialog(null,"Marca: " + m2.getMarca() + "\nColor: " + m2.getColor() + "\nReferencia: " + m2.getReferencia() + "\nPeso: "  + m2.getPeso() + "\nDimensiones: " + m2.getDimensiones());
       
        
    }
    
}
