package Nevera;

import javax.swing.JOptionPane;

public class Principal {

    public static void main(String[] args) {
        Nevera n = new Nevera();
        JOptionPane.showMessageDialog(null, "Nevera 1");

        n.setTiporefrigeracion(JOptionPane.showInputDialog("Tipo de refrigeracion: "));

        n.setCapacidadbruta(Integer.parseInt(JOptionPane.showInputDialog("Capacidad bruta: ")));

        n.setCantidadpuertas(Integer.parseInt(JOptionPane.showInputDialog("Cantidad de puertas: ")));

        n.setDimensiones(Integer.parseInt(JOptionPane.showInputDialog("Dimensiones: ")));

        n.setclasificacionenergetica(JOptionPane.showInputDialog("Clasificacion energetica: "));

        JOptionPane.showMessageDialog(null, "Nevera 1: "
                + "\nTipo de refrigeracion: " + n.getTiporefrigeracion()
                + "\nCapacidad bruta: " + n.getCapacidadbruta()
                + "\nCantidad de puertas: " + n.getCantidadpuertas()
                + "\nDimensiones: " + n.getDimensiones()
                + "\nClasificacion energetica: " + n.getClasificaciongenerica());

        Nevera n2 = new Nevera();
        JOptionPane.showMessageDialog(null, "Nevera 2");

        n2.setTiporefrigeracion(JOptionPane.showInputDialog("Tipo de refrigeracion: "));

        n2.setCapacidadbruta(Integer.parseInt(JOptionPane.showInputDialog("Capacidad bruta: ")));

        n2.setCantidadpuertas(Integer.parseInt(JOptionPane.showInputDialog("Cantidad de puertas: ")));

        n2.setDimensiones(Integer.parseInt(JOptionPane.showInputDialog("Dimensiones: ")));

        n2.setclasificacionenergetica(JOptionPane.showInputDialog("Clasificacion energetica: "));

        JOptionPane.showMessageDialog(null, "Nevera 2: "
                + "\nTipo de refrigeracion: " + n2.getTiporefrigeracion()
                + "\nCapacidad bruta: " + n2.getCapacidadbruta()
                + "\nCantidad de puertas: " + n2.getCantidadpuertas()
                + "\nDimensiones: " + n2.getDimensiones()
                + "\nClasificacion energetica: " + n2.getClasificaciongenerica());

    }

}
