
package Nevera;

public class Nevera {
    
    private String tiporefrigeracion;
    private int capacidadbruta;
    private int cantidadpuertas;
    private int dimensiones;
    private String clasificacionenergetica;

    public String getTiporefrigeracion() {
        return tiporefrigeracion;
    }

    public void setTiporefrigeracion(String tiporefrigeracion) {
        this.tiporefrigeracion = tiporefrigeracion;
    }

    public int getCapacidadbruta() {
        return capacidadbruta;
    }

    public void setCapacidadbruta(int capacidadbruta) {
        this.capacidadbruta = capacidadbruta;
    }

    public int getCantidadpuertas() {
        return cantidadpuertas;
    }

    public void setCantidadpuertas(int cantidadpuertas) {
        this.cantidadpuertas = cantidadpuertas;
    }

    public int getDimensiones() {
        return dimensiones;
    }

    public void setDimensiones(int dimensiones) {
        this.dimensiones = dimensiones;
    }

    public String getClasificaciongenerica() {
        return clasificacionenergetica;
    }

    public void setclasificacionenergetica(String clasificacionenergetica) {
        this.clasificacionenergetica = clasificacionenergetica;
    }
}
