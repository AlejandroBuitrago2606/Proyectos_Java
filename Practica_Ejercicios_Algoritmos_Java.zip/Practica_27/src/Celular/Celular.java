package Celular;

public class Celular {
 
    private int RAM;
    private int MemoriaInterna;
    private String Tipocamara;
    private int capbateria;
    private String reddatos;

    public int getRAM() {
        return RAM;
    }

    public void setRAM(int RAM) {
        this.RAM = RAM;
    }

    public int getMemoriaInterna() {
        return MemoriaInterna;
    }

    public void setMemoriaInterna(int MemoriaInterna) {
        this.MemoriaInterna = MemoriaInterna;
    }

    public String getTipocamara() {
        return Tipocamara;
    }

    public void setTipocamara(String Tipocamara) {
        this.Tipocamara = Tipocamara;
    }

    public int getCapbateria() {
        return capbateria;
    }

    public void setCapbateria(int capbateria) {
        this.capbateria = capbateria;
    }

    public String getReddatos() {
        return reddatos;
    }

    public void setReddatos(String reddatos) {
        this.reddatos = reddatos;
    }
    
}
