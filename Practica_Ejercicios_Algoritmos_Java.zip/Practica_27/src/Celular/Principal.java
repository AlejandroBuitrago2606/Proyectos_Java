package Celular;

import javax.swing.JOptionPane;

public class Principal {

    public static void main(String[] args) {
        Celular c = new Celular();

        JOptionPane.showMessageDialog(null, "Celular 1");
        c.setRAM(Integer.parseInt(JOptionPane.showInputDialog("Ingresa la RAM: ")));
        c.setMemoriaInterna(Integer.parseInt(JOptionPane.showInputDialog("Ingresa la memoria interna: ")));
        c.setTipocamara(JOptionPane.showInputDialog("Ingresa el tipo de camara: "));
        c.setCapbateria(Integer.parseInt(JOptionPane.showInputDialog("Ingresa la capacidad de la bateria: ")));
        c.setReddatos(JOptionPane.showInputDialog("Ingresa la red de datos: "));
        
        JOptionPane.showMessageDialog(null, "Celular 1: " + "\n RAM: " + c.getRAM() + "GB" + "\nMemoria Interna: " + c.getMemoriaInterna() + "MB" + "\nTipo de camara: " + c.getTipocamara() + "\nCapacidad de la bateria: " + c.getCapbateria() + "mAh" + "\nRed de datos: " + c.getReddatos() + "G");
        
        
        Celular c2 = new Celular();

        JOptionPane.showMessageDialog(null, "Celular 2");
        c2.setRAM(Integer.parseInt(JOptionPane.showInputDialog("Ingresa la RAM: ")));
        c2.setMemoriaInterna(Integer.parseInt(JOptionPane.showInputDialog("Ingresa la memoria interna: ")));
        c2.setTipocamara(JOptionPane.showInputDialog("Ingresa el tipo de camara: "));
        c2.setCapbateria(Integer.parseInt(JOptionPane.showInputDialog("Ingresa la capacidad de la bateria: ")));
        c2.setReddatos(JOptionPane.showInputDialog("Ingresa la red de datos: "));
        
        JOptionPane.showMessageDialog(null, "Celular 2: " + "\n RAM: " + c2.getRAM() + "GB" + "\nMemoria Interna: " + c2.getMemoriaInterna() + "MB" +  "\nTipo de camara: " + c2.getTipocamara() + "\nCapacidad de la bateria: " + c2.getCapbateria() + "mAh" + "\nRed de datos: " + c2.getReddatos() + "G");
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    }

}
