package practica_39;

import java.util.LinkedList;

public class Practica_39 {

    public static void main(String[] args) {

        LinkedList<String> nombres = new LinkedList<String>();

        nombres.add("Victor");
        nombres.add("Enrique");
        nombres.add("Yojan");
        nombres.add("Juan");

        System.out.println(nombres);

        //agregar
        nombres.add("hola");
        nombres.addFirst("carlos");
        nombres.addLast("Sanchez");

        System.out.println(nombres);

//eliminar
        nombres.remove("hola");

        nombres.removeFirst();
        nombres.removeLast();
        System.out.println(nombres);
        
        
        
        
        
        
        
    }

}
