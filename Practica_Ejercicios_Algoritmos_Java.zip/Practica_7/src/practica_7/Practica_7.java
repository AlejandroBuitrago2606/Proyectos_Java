package practica_7;

import java.util.Scanner;
import javax.swing.JOptionPane;

public class Practica_7 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int op;
        boolean salir = false;
        double numero, resultado;
        while (!salir) {

            System.out.println("*********************");
            System.out.println("1. Raiz Cuadrada");
            System.out.println("2. Raiz Cubica");
            System.out.println("3. Potencia");
            System.out.println("4. Salir");
            System.out.println("*********************");
            JOptionPane.showMessageDialog(null, "Escoje una opcion");
            op = sc.nextInt();

            switch (op) {
                case 1:
                    System.out.println("Digite un numero: ");
                    numero = sc.nextDouble();
                    resultado = Math.sqrt(numero);
                    System.out.println("La raiz de " + numero + "es: " + resultado);
                    break;
                case 2:
                    System.out.println("Digite un numero: ");
                    numero = sc.nextDouble();
                    resultado = Math.cbrt(numero);
                    System.out.println("La raiz cubica de " + numero + "es: " + resultado);
                    break;
                case 3:
                    System.out.println("Dijite un numero: ");
                    numero = sc.nextDouble();
                    resultado = Math.pow(numero, 2);
                    System.out.println("La potencia de " + numero + "es: " + resultado);
                case 4:
                    salir = true;
                    break;
                default:
                    System.out.println("Solamente digite las opciones correctas!!!");//(LEE Y ADVIERTE DEL ERROR EN CONSOLA
            }
            /*switch (var) {
                case 1:
                    
                    break;
                default:
                    throw new AssertionError()(LEE Y ADVIERTE DEL ERROR EN CONSOLA);
             */
        }
    }

}
