package practica_10;

import java.util.Scanner;

public class Practica_10 {

    public static void main(String[] args) {
        /*La camara de comercio de Sogamoso,
        necesita registrar los establecimientos
        matriculados para realizar dicho registro, se necesita
        ingresar
         */
        Scanner sc = new Scanner(System.in);
        System.out.println("Ingrese el numero de establecimientos para renovar: ");
        int numeroEstablecimientos = sc.nextInt();
        
        //Bucle para iterar cada establecimiento
        for (int i = 1; i <= numeroEstablecimientos; i++) {
            //Solicitar datos de la empresa
            System.out.println(".::Establecimiento" + i + "::.");
            System.out.println("Dijite el Nit de la empresa: ");
            String nit = sc.next();
            System.out.println("Dijite el nombre de la empresa: ");
            String nombre = sc.next();
            System.out.println("Dijite la fecha de la matricula: ");
            String fechaMatricula = sc.next();
            System.out.println("Dijite la fecha de renovacion: ");
            String fecharenovacion = sc.next();
            System.out.println("Dijite el valor de la renovacion: ");
            double valorRenovacion = sc.nextDouble();
            //Mostramos los resultados
            System.out.println("Nit: " + nit);
            System.out.println("Nombre Empresa: " + nombre);
            System.out.println("Fecha Matricula: " + fechaMatricula);
            System.out.println("Fecha Renovacion: " + fecharenovacion);
            System.out.println("Valor Renovacion: " + valorRenovacion);

            
            
            
            
            
        }
        
        
        
        
        
        
        
    }

}
