
package practica_38;

public class Practica_38 {

    public static void main(String[] args) {
       
    }
    
}
