package practica_38;

import java.util.ArrayList;

public class ListAprendiz {
ArrayList<Aprendiz> listaaprendiz = new ArrayList();

}
