package practica_38;

public class Aprendiz {

private String ficha;
private String nombre;
private String celular;
private String direccion;

public Aprendiz(){
    ficha = "";
    nombre = "";
    celular = "";
    direccion = "";
                 
}

    public String getFicha() {
        return ficha;
    }

    public void setFicha(String ficha) {
        this.ficha = ficha;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCelular() {
        return celular;
    }

    public void setCelular(String celular) {
        this.celular = celular;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }




}