package practica_8;

import java.util.Scanner;

public class Practica_8 {

    public static void main(String[] args) {
        /*
        -simplicidad y concision : Es util cuando se trata
        de epresiones simples.
        -Codigo mas compacto y facil de leer en situaciones 
        en donde la logica es directa y no involucra 
        multiples ramificaciones.
        -Es ideal para asignaciones directas basadas en una condicion.
        -Sintaxis: variable = (condicion) ? Expresion verdadera : Expresion falsa;
         */
        Scanner sc = new Scanner(System.in);
        int edad;
        String resultado;
        System.out.println("Escriba su edad");
        edad = sc.nextInt();
        if (edad >= 18) {
            System.out.println("Es mayor de edad");
        } else {
            System.out.println("No es mayor de edad");
        }
        System.out.println("=========Operador Ternario=========");
        resultado = (edad >= 18) ? "Mayor de Edad" : "Menor de Edad";
        System.out.println(resultado);
        int num1, num2, mayor;
        System.out.println("Escriba un numero");
        num1 = sc.nextInt();
        System.out.println("Escriba otro numero");
        num2 = sc.nextInt();
        if (num1 > 2) {
            mayor = num1;
        } else {
            mayor = num2;
        }
        System.out.println("El numero mayor es: " + mayor);
        int may = (num1 > num2) ? num1 : num2;
        System.out.println(may);
        double velocidad;
        System.out.println("Dijiten la velocidad");
        velocidad = sc.nextDouble();
        if (velocidad <= 30) {
            System.out.println("Es residencial");
        } else if ((velocidad > 30) && (velocidad <= 60)) {
            System.out.println("Es urbana");
        } else {
            System.out.println("Es autopista");
        }
        String mens = (velocidad <= 30) ? "Es residencial" : ((velocidad > 30) && (velocidad < 60))/*<---condiciones*/ ? "Es urbana" /*es verdadera*/: "Autopista";/*Es falsa*/
        System.out.println(mens);

    }

}
