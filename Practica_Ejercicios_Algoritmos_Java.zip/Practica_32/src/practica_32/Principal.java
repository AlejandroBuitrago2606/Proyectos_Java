package practica_32;

public class Principal {

    public static void main(String[] args) {
    }

}
