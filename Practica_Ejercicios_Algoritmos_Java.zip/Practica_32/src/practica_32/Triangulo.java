package practica_32;

public class Triangulo {
private double base;
private double altura;

    public Triangulo(double base, double altura) {
        this.base = base;
        this.altura = altura;
    }

public static double calcularAreaTriangulo (double base,double altura){
    return (base*altura)/2;
}

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
