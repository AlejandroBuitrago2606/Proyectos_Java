
package practica_34_figura;

public interface Figura {
    double calcularArea();
    double calcularPerimetro();
}
