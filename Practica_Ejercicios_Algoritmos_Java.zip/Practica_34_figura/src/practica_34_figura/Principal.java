package practica_34_figura;

public class Principal {

    public static void main(String[] args) {

        Figura tr = new Triangulo(5, 10);

        System.out.println("******************************************");
        System.out.println("Triangulo");
        System.out.println("Area: "  + tr.calcularArea());
        System.out.println("Perimetro: " + tr.calcularPerimetro());
        System.out.println("****************************");
        System.out.println("Cuadrado");
        Figura cuadrado = new Cuadrado(4);
        System.out.println("Area: "  + cuadrado.calcularArea());
        System.out.println("Perimetro: " + cuadrado.calcularPerimetro());
        System.out.println("************************************");
        System.out.println("Circulo");
        Figura circulo = new Circulo(4);
        System.out.println("Area: "  + circulo.calcularArea());
        System.out.println("Perimetro: " + circulo.calcularPerimetro());
        System.out.println("**************************************");
        System.out.println("Rectangulo");
        Figura rect = new Rectangulo(3, 2);
        System.out.println("Area: "  + rect.calcularArea());
        System.out.println("Perimetro: " + rect.calcularPerimetro());
        System.out.println("******************************************");
        
        

        
}
    
    }

