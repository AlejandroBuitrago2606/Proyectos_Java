package practica_16;

public class Calculos {

    public double calculararea(double base, double altura) {
        return (base * altura) / 2;
    }

    public double calcularperimetro(double base, double altura) {
        double lad1 = Math.sqrt(Math.pow(base / 2, 2)) + Math.pow(altura, 2);
        double lad2 = lad1;
        return base + lad1 + lad2;

    }
}


    

