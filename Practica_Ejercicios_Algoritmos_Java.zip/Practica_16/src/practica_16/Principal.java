package practica_16;

import java.util.Scanner;

public class Principal {
    public static void main(String[] args) {
        Calculos cal = new Calculos(); //aqui llamo a la funcion de el otro ducumento
        Scanner sc = new Scanner (System.in);
        
        
         /*
        Elabore un programa que calcule el area
        y perimetro de un triangulo
         */
        System.out.println("Dijite la base");
        double base = sc.nextDouble();
        System.out.println("Dijite la altura");
        double altura = sc.nextDouble();

        double area = cal.calculararea(base, altura);//lee la cantidad de variables que asigne y las lleva al otro documento
        double perimetro = cal.calcularperimetro(base, altura);//lee la cantidad de variables que asigne y las lleva al otro documento

        System.out.println("El area del triangulo es: " + area);
        System.out.println("El perimetro del triangulo es: " + perimetro);
        
    }
}
