package Aprendiz;

public class Principal {

    public static void main(String[] args) {
        /*
        lA CLASE OBJECT:
        Clase raiz de todas las clases de Java, se encuentra en el paquete Java.lang,
        el cual es el paquete principal o core de JAVA, no hay necesidad de hacer import.
        Metodos: 
        -ToString: Imprimir o mostrar el estado de un objeto.
        -Equals: Se utilizan para saber si dos objetos son iguales.
        -HashCode: 
        
         */

        Aprendiz ap1 = new Aprendiz("2827167", "Juan", "25");
        Aprendiz ap2 = new Aprendiz("2827167", "Juan", "25");
        Aprendiz ap3 = new Aprendiz("2827167", "Alejandra", "20");

        //comparacion con equals
        System.out.println("Aprendiz 1 y 2 Son iguales: " + ap1.equals(ap2));
        System.out.println("Aprendiz 1 y 3 Son iguales: " + (ap1 != ap2));
        System.out.println("Aprendiz 2 y 3 Son iguales: " + ap2.equals(ap3));

        //HashCode
        System.out.println("HashCode de aprendiz 1: " + ap1.hashCode());
        System.out.println("HashCode de aprendiz 2: " + ap2.hashCode());
        System.out.println("HashCode de aprendiz 3: " + ap3.hashCode());
        
        
        
        
        
        
        
        
        
    }
    

}
