package Aprendiz;

import java.util.Objects;

public class Aprendiz {
private String ficha;
private String nombre;
private String edad;

//constructor
    public Aprendiz(String ficha, String nombre, String edad) {
        this.ficha = ficha;
        this.nombre = nombre;
        this.edad = edad;
    }
    
//setters y getters
    public String getFicha() {
        return ficha;
    }

    public void setFicha(String ficha) {
        this.ficha = ficha;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getEdad() {
        return edad;
    }

    public void setEdad(String edad) {
        this.edad = edad;
    }

    //HashCode
    @Override
    public int hashCode() {
        int hash = 3;
        hash = 53 * hash + Objects.hashCode(this.ficha);
        hash = 53 * hash + Objects.hashCode(this.nombre);
        hash = 53 * hash + Objects.hashCode(this.edad);
        return hash;
    }

    //Equals
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Aprendiz other = (Aprendiz) obj;
        if (!Objects.equals(this.ficha, other.ficha)) {
            return false;
        }
        if (!Objects.equals(this.nombre, other.nombre)) {
            return false;
        }
        return Objects.equals(this.edad, other.edad);
    }

    //To String
    @Override
    public String toString() {
        return "Aprendiz{" + "ficha=" + ficha + ", nombre=" + nombre + ", edad=" + edad + '}';
    }


}
