
package practica_12;

public class Practica_12 {

    public static void main(String[] args) {       
        /*
        Funciones o metodos:
        So
        */
    Scanner leer = new 
    
    }
    
}
