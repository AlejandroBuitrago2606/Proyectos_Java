package practica_36;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public class Practica_36 {

    public static void main(String[] args) {

        //ArrayList
        //Inicializar los ArrayList
        ArrayList<String> nombre = new ArrayList();
        ArrayList<Integer> edad = new ArrayList();

        //add: agrega elementos al array
        //EL indice empieza en cero
       

        //agregamos elementos al array nombre
        nombre.add("Juan");
        nombre.add("Ricardo");
        nombre.add("diego");

         for (Object i : nombre) {
            System.out.println(i);
        }
         Iterator<String> nom =nombre.iterator();
         
         while (nom.hasNext()) {
            Object elemento = nom.next();
             System.out.println("\n" + elemento + " ");
        }
        
        //agregamos elementos al array edad
        edad.add(2);
        edad.add(4);
        edad.add(3);
        
        for (Object j : edad) {
            System.out.println(j);
        }
        
        
        Iterator<Integer> ed = edad.iterator();
        while (nom.hasNext()) {
            Object elemento = ed.next();
             System.out.println("\n" + elemento + " ");
        }

        //Arreglar los datos en orden ascendente
        Collections.sort(nombre);
        Collections.sort(edad);
        
        
        //Mostrar elementos
        System.out.println("Mostrando los arrays: " + "\n" + nombre + "\n" + edad);
        
        //Arreglar los datos en orden descendente
        Collections.sort(nombre,Collections.reverseOrder());
         Collections.sort(edad,Collections.reverseOrder());
         
         //Buscar
         System.out.println("Busqueda " + Collections.binarySearch(nombre, "Juan"));
        System.out.println(nombre);
        System.out.println(edad);

        //Mostrar los datos por indice 
        System.out.println("Nombre 1: " + nombre.get(1));
        System.out.println("Elementos por indice: " + edad.get(0));

        //verificar si existe un elemento true o false
        System.out.println("Verificar existencia: del nombre: " + nombre.contains("Juan"));
        System.out.println("Verificar existencia: de la edad: " + edad.contains(3));

        //Mostrar la cantidad de elementos que hay en el array
        System.out.println("Cantidad de elementos array nombre: " + nombre.size());
        System.out.println("Cantidad de elementos array edad: " + edad.size());

        //Mostrar la ubicacion de un elemento dentro del array
        System.out.println("Ubicacion en array nombre: " + nombre.indexOf("Juan"));
        System.out.println("Ubicacion en array edad: " + edad.indexOf("Juan"));

        //Eliminar elemento usando numero de indice del array
        System.out.println("Eliminar elemento por indice array nombre: " + nombre.remove(0));
        System.out.println("Eliminar elemento por indice array edad: " + nombre.remove(0));

        //agregar elementos con set al array (Pero eso limpiara el array)
        // ---->  System.out.println("Array List Nombre: " + nombre.set(0, "Victor"));
        //Eliminar por contenido
//        System.out.println("Eliminar por contenido array nombre: " + nombre.remove("Juan"));
//        System.out.println("Eliminar por contenido array edad: " + edad.remove(4));
        System.out.println("El elemento que queda despues de eliminar: " + nombre);
    }

}
