package practica_37;

import java.util.ArrayList;

public abstract class Persona {

    private ArrayList<String> nombre;
    private ArrayList<Integer> edad;
    private ArrayList<String> profesion;

    public Persona(ArrayList<String> nombre, ArrayList<Integer> edad, ArrayList<String> profesion) {
        this.nombre = nombre;
        this.edad = edad;
        this.profesion = profesion;
    }

    public ArrayList<String> getNombre() {
        return nombre;
    }

    public void setNombre(ArrayList<String> nombre) {
        this.nombre = nombre;
    }

    public ArrayList<Integer> getEdad() {
        return edad;
    }

    public void setEdad(ArrayList<Integer> edad) {
        this.edad = edad;
    }

    public ArrayList<String> getProfesion() {
        return profesion;
    }

    public void setProfesion(ArrayList<String> profesion) {
        this.profesion = profesion;
    }

    public abstract int CalcularEdadMayor();

    public abstract int CalcularEdadMenor();

    @Override
    public String toString() {
        return "Persona{" + "nombre=" + nombre + ", edad=" + edad + ", profesion=" + profesion + '}';
    }

    
    public boolean buscar(String nombrebusqueda) {
        return nombre.contains(nombrebusqueda);
    }

    public void adicionar(String nombre, int edad, String profesion) {
        this.nombre.add( nombre);
        this.edad.add(edad);
        this.profesion.add(profesion);
    }
    
   //indexOf = busca la ubicacion del elemento; 
    public void eliminar (String nomb){
        int indice = nombre.indexOf(nomb);
        if (indice>=0){
            nombre.remove(indice);
            edad.remove(indice);
            profesion.remove(indice);
        }
        
    }
}
