package practica_37;

import java.util.ArrayList;

public class Principal {

    public static void main(String[] args) {
        ArrayList<String> nombres = new ArrayList<>();
        nombres.add("Juan");
        nombres.add("sandra");
        nombres.add("Pedro");

        ArrayList<Integer> edades = new ArrayList<>();
        edades.add(35);
        edades.add(30);
        edades.add(40);

        ArrayList<String> profesiones = new ArrayList<>();
        profesiones.add("ingeniero");
        profesiones.add("abogada");
        profesiones.add("Psicologo");
        
        Operaciones listaPersonas = new Operaciones(nombres, edades, profesiones);
        System.out.println("Nombres: " + nombres);
        System.out.println("Edades: " + edades);
        System.out.println("Profesiones: " + profesiones);
        System.out.println("Listado" + listaPersonas);
        
        System.out.println("Mostrar un elemento de la lista: " + nombres.get(1));
       
        //para buscar un elemento existente
        boolean search = listaPersonas.buscar("Felipe");
        System.out.println("Existe felipe?: " + search);
        
        //agregar 
        listaPersonas.adicionar("ana", 25, "Medico");
        System.out.println("Listado: " + listaPersonas);
        
        //cantidad de Elementos de la lista 
        System.out.println("Cantidad de Personas: " + listaPersonas.getNombre().size());




















    }

}
