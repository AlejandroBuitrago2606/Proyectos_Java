package practica_37;

import java.util.ArrayList;

public class Operaciones extends Persona {

    public Operaciones(ArrayList<String> nombre, ArrayList<Integer> edad, ArrayList<String> profesion) {
        super(nombre, edad, profesion);
    }

    @Override
    public int CalcularEdadMayor() {
        int EdadMayor = 0;
        for (Integer edadActual : this.getEdad()) {

            EdadMayor = Math.max(EdadMayor, edadActual);
        }
        return EdadMayor;
    }

    @Override
    public int CalcularEdadMenor() {
        int edadMenor = Integer.MAX_VALUE;
        for (Integer edadActual : this.getEdad()) {
            edadMenor = Math.min(edadMenor, edadActual);
        }

        return edadMenor;
    }

}
