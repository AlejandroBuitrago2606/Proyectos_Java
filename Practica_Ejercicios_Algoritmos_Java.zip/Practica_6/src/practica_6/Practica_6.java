
package practica_6;
import java.util.Scanner;
import javax.swing.JOptionPane;

public class Practica_6 {

    public static void main(String[] args) {
        //Solicitud de datos por teclado
        Scanner sc = new Scanner (System.in);
        String nombre,apellido,direccion,celular;
        int edad;
        System.out.println("Registro de informacion del aprendiz");
        System.out.println("======================================");
        System.out.println("Dijte su nombre: ");
        nombre = JOptionPane.showInputDialog("Nombre");
        apellido = JOptionPane.showInputDialog("Apellido");
        edad = Integer.parseInt(JOptionPane.showInputDialog("Edad"));
        direccion = JOptionPane.showInputDialog("Direccion");
        celular = JOptionPane.showInputDialog("Celular");
        
        
        /*nombre = sc.nextLine();
        System.out.println("Dijite su apellido: ");
        apellido = sc.nextLine();
        System.out.println("Dijite su edad: ");
        edad = sc.nextInt();
        System.out.println("Dijite su direccion: ");
        direccion = sc.next();
        System.out.println("Dijite su numero de celular: ");
        celular = sc.next();
        System.out.println("======================================");
        System.out.println("***********Datos Capturados***********");
        System.out.println("Nombre del aprendiz: "+nombre + " " + apellido);
        System.out.println("La edad es: " + edad);
        System.out.println("Direccion: "+direccion);
        System.out.println("El numero de Celular: " + celular);
*/
        JOptionPane.showMessageDialog(null,"\nNombre:" + nombre + "\nApellido:"+ apellido + "\nEdad: " + edad + "\nDireccion: "+ direccion + "\nCelular: "+ celular);
        
               
    }
    
}
