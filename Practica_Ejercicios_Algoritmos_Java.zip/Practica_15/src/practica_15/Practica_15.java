package practica_15;

import java.util.Scanner;

public class Practica_15 {

    public static void main(String[] args) {
        /*
        Elabore un programa que calcule el area
        y perimetro de un triangulo
         */
        Scanner sc = new Scanner(System.in);
        System.out.println("Dijite la base");
        double base = sc.nextDouble();
        System.out.println("Dijite la altura");
        double altura = sc.nextDouble();

        double area = calculararea(base, altura);
        double perimetro = calcularperimetro(base, altura);

        System.out.println("El area del triangulo es: " + area);
        System.out.println("El perimetro del triangulo es: " + perimetro);
        
        
    }

    public static double calculararea(double base, double altura) {
        return (base * altura) / 2;
    }

    public static double calcularperimetro(double base, double altura) {
        double lad1 = Math.sqrt(Math.pow(base / 2, 2)) + Math.pow(altura, 2);
        double lad2 = lad1;
        return base + lad1 + lad2;
        
    }
}
