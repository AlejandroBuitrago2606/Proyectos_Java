
package practica_24;

public class Practica_24 {

    public static void main(String[] args) {
        for (int i = 0; i < 10; i++) {
            if (i==4) {
                break;//Detiene el ciclo for cuando i es igual a 4
            }
            System.out.println(i);
        }
        
        for (int i = 0; i < 10; i++) {
            if (i==4) {
                continue;//Interrumpe el for si se produce la condicion 
                //y continua con la siguiente iteracion del bucle.
                
            }
            System.out.println(i);
        }
        
        
        
        
    }
    
}
