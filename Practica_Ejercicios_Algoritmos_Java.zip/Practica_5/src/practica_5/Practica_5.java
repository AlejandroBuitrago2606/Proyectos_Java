package practica_5;

public class Practica_5 {

    public static void main(String[] args) {
//La indiferencia es una forma de pereza, y la pereza
//es uno de los sintomas del desamor.Nadie es haragan
//con lo que ama.San Basilio Magno
        String frase1 = " La indiferencia es una forma de pereza, y la pereza";
        String frase2 = " es uno de los sintomas del desamor";
        String frase3 = " Nadie es haragan con lo que ama.San Basilio Magno";

//FUNCIONES DE TEXTO EN JAVA
//length(): Muestra la longitud de la cadena
        System.out.println("el tamaño de la frase 1 es: " + frase1.length());
//toUpperCase(): Convierte el texto en mayusculas
        System.out.println("Frase 2 en Mayusculas: " + frase2.toUpperCase());
//toLowerCase(): Convierte el texto en minusculas
        System.out.println("Frase 3 en Minusculas: " + frase3.toLowerCase());
//indexOf(): Retorna la posicion de un texto especifico
        System.out.println(frase2.indexOf("desamor"));
//concat(): Sirve para unir dos cadenas de texto
        System.out.println(frase1.concat(frase2.concat(frase3)));
//otra forma de concatenar
        System.out.println(frase1 + " " + frase2 + " " + frase3);
//Suma de Strings
        String a = "30", b = "15";
        String c = a + b;
        System.out.println("La suma de cadenas es: " + c);

//FUNCIONES Math():
//Exponenciacion neperiana
        double d = Math.exp(1);
        System.out.println("La respuesta Exponenciacion Neperiana es: " + d);
//Logaritmo
        double e = Math.log(1.70);
        System.out.println("La respuesta Logaritmo Neperiano es: " + e);
//Potenciacion
        double f = Math.pow(6, 2);
        System.out.println("el numero 6 elevado a la 2 = " + f);
//Raiz cuadrada
        double g = Math.sqrt(81);
        System.out.println("Raiz cuadrada = " + g);
//Raiz cubica
        double h = Math.cbrt(64);
        System.out.println("Raiz cubica = " + h);
//Redondeo al entero menor
        double i = Math.floor(2.94);
        System.out.println("Redondeo al entero menor " + i);
//Redondeo al entero mayor
        double j = Math.ceil(2.98);
        System.out.println("Redondeo al entero mayor " + j);
//Redondeo
        double k = Math.round(3.56);
        System.out.println("Redondeo al entero menor " + k);
//Max El Mayor Valor
        double l = Math.max(7, 15);
        System.out.println("El numero mayor es: " + l);
//Min El Menor Valor
        double n = Math.min(7, 15);
        System.out.println("El numero menor es: " + n);
//Generar numeros aleatorios random()
        double o = Math.random();
        System.out.println("Numeros aleatorios: " + o);
//Generar numeros aleatorios de 0 al 20
        double p = (int) (Math.random() * 20);
        System.out.println("Numeros aleatorios: " + p);
        //

        //Comparacion
        int ax = 5, by = 6;
        System.out.println("igual: " + (ax == by));
    }

}
