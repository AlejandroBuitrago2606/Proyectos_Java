
package practica_22;

import java.util.Scanner;

public class Practica_22 {

   public static void main(String[] args) {
        /*
        elabore un programa en java que solicite por teclado
        el numero de filas y columnas
        */
        Scanner sc = new Scanner(System.in);
        int m,n;
        
        System.out.println("digite el numero de filas");
        m = sc.nextInt();
        System.out.println("digite el numero de columnas");
        n = sc.nextInt();
        int matrix[][] = new int [m][n];
        //lenado de la matriz
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
            matrix[i][j] = (int) (Math.random()*30+1);
        }
        }
        System.out.println("matriz de " + m + "x" + n);
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                System.out.print(matrix[i][j] + " ");
            }
            System.out.println();
        }
        
        
        
        
        
    }
}
