
package practica_33;

public class Aprendiz extends Persona {
    private String ficha;
    private int nota;

    public Aprendiz(String nombre, String genero, String ficha, int nota ) {
        super(nombre, genero);
        this.ficha = ficha;
        this.nota = nota;
    }

    public String getFicha() {
        return ficha;
    }

    public void setFicha(String ficha) {
        this.ficha = ficha;
    }

    public int getNota() {
        return nota;
    }

    public void setNota(int nota) {
        this.nota = nota;
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
