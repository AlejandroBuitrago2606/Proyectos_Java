package practica_33;

public class Coordinador extends Persona{
private String Tipo;
private String Jornada;

    public Coordinador(String nombre, String genero, String Tipo, String Jornada) {
        super(nombre, genero);
        this.Tipo = Tipo;
        this.Jornada = Jornada;
    }

    public String getTipo() {
        return Tipo;
    }

    public void setTipo(String Tipo) {
        this.Tipo = Tipo;
    }

    public String getJornada() {
        return Jornada;
    }

    public void setJornada(String Jornada) {
        this.Jornada = Jornada;
    }



}
