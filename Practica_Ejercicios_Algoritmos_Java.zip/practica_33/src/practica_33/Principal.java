package practica_33;

public class Principal {

    public static void main(String[] args) {
        Aprendiz ap = new Aprendiz("Carlos", "masculino", "2827167", 0);
        Coordinador cor = new Coordinador("Gustavo", "Masculino", "academico", "Manana");
        Instructor inst = new Instructor("Gustavo", "Masculino", "C#", "Ingeniero");
        System.out.println("**Aprendiz**********************");
        System.out.println("Nombre: " + ap.getNombre()
                + "\nGenero: " + ap.getGenero()
                + "\nFicha: " + ap.getFicha()
                + "\nNota: " + ap.getNota());
        System.out.println("**Coordinador**********************");
        System.out.println("Nombre: " + cor.getNombre()
                + "\nGenero: " + cor.getGenero()
                + "\nTipo: " + cor.getTipo()
                + "\nJornada: " + cor.getJornada());
        System.out.println("**Instructor**********************");
        System.out.println("Nombre: " + inst.getNombre()
                + "\nGenero: " + inst.getGenero()
                + "\nLenguaje dominio: " + inst.getLenguaje()
                + "\nProfesion: " + inst.getProfesion());
    }

}
