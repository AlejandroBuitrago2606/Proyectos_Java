
package practica_33;

public class Instructor extends Persona{
    private String lenguaje;
    private String profesion;

    public Instructor(String nombre, String genero,String lenguaje, String profesion ) {
        super(nombre, genero);
        this.lenguaje = lenguaje;
        this.profesion = profesion;
    }

    public String getLenguaje() {
        return lenguaje;
    }

    public void setLenguaje(String lenguaje) {
        this.lenguaje = lenguaje;
    }

    public String getProfesion() {
        return profesion;
    }

    public void setProfesion(String profesion) {
        this.profesion = profesion;
    }

    
    
}
