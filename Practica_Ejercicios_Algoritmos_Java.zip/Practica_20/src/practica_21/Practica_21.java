package practica_21;

public class Practica_21 {

    public static void main(String[] args) {

    }

}
