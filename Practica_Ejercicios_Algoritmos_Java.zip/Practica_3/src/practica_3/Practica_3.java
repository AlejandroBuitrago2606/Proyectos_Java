package practica_3;

public class Practica_3 {

    public static void main(String[] args) {
//variables
/*
CLASES DE VARIABLES: Locales, Globales, instancias y estaticas
int - long - short - byte: Almacena numeros enteros
float: Almacena decimales (8 decimales)
char: Almacena caracteres individuales ejemplo:'p'
String: Almacena cadenas de texto ejemplo:"Hoy es jueves"
Boolean: Almacena dos valores: TRUE - FALSE
double: Almacena decimales, bien sean positivos o negativos


VARIABLE:Una variable refiere, en una primer instancia, a cosas que son susceptibles de ser
modificadas (de variar), de cambiar en función de algún motivo determinado o indeterminado.


TIPO DE DATO: un tipo de dato informático,es un atributo de los datos que indica al ordenador 
(y/o al programador/programadora) sobre la clase de datos que se va a manejar.
*/


/*
Declaracion de variables
formas validas de declararlas
*/
int suma;
double temperaturaPromedio;
float masa;
long valor_prestamo;
short variable1;
char LETRA;

//*******************************************
//Forma no valida






         int n=3,n1=5,n2=7;
         float f,f1,f2;
        System.out.println("la variable n=" + " "+n);
        n=20;
        System.out.println("ahora la variable tiene el valor n=" + " "+n);
        
        //FLOAT
        f = 7.12345689f;
                System.out.println("El tipo de variable es float y su valor es f =" + " "+f);
        //DOUBLE
        double d = 52.258455665d;
        System.out.println("El tipo de variable es double y su valor es d =" + " "+d);
        
        //BYTE
        byte b = 9;
        System.out.println("el tipo de variable es byte y su valor es b =" + " "+b);
        
        //SHORT
        short s = 15;
        System.out.println("el tipo de variable es short y su valor es s =" + " "+s);
        
        //LONG
        long l = 9876543210L;
        System.out.println("el tipo de variable es long y su valor es l =" + " "+l);
         
        //CHAR
        char c = '0';
        System.out.println("el tipo de variable es char y su valor es c =" + " "+c);
        
        //STRING
        String mensaje = "\033[32mNo hay que ir para atras, ni para darse impulso";
        System.out.println("Frase:" + " "+mensaje);
        
        //BOOLEAN
        boolean bl = true;
        System.out.println("el tipo de variable es booleana y su valor es bl =" + " "+bl);
        
        //DECLARAR CONSTANTE
        final double velSonido = 33.6;
        System.out.println("el valor de la constante es velsonido =" + " "+velSonido + " m/s");
        
        
        /*CLASES DE VARIABLES: Locales, Globales, instancias y estaticas
int - long - short - byte: Almacena numeros enteros
float: Almacena decimales (8 decimales)
char: Almacena caracteres individuales ejemplo:'p'
String: Almacena cadenas de texto ejemplo:"Hoy es jueves"
Boolean: Almacena dos valores: TRUE - FALSE
double: Almacena decimales, bien sean positivos o negativos
        */
   
                
        
                
        
        
        
        
        
    }

}
