package ejercicio_de_funciones_1;

import java.util.Scanner;

public class Ejercicio_de_funciones {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        boolean salir = false;
        double numero, numero2;
        System.out.println("*********************");
        System.out.println("1. suma");
        System.out.println("2. Resta");
        System.out.println("3. Multiplicacion");
        System.out.println("4. Division");
        System.out.println("5. Salir");
        System.out.println("*********************");
        System.out.println("Escoja un opcion");
        int op = sc.nextInt();
        switch (op) {
            case 1:
                System.out.println("Digite dos numeros: ");
                numero = sc.nextDouble();
                numero2 = sc.nextDouble();
                double rtasuma = suma(numero, numero2);
                System.out.println("El resultado de la suma es: " + rtasuma);
                break;
            case 2:
                System.out.println("Digite dos numeros: ");
                numero = sc.nextDouble();
                numero2 = sc.nextDouble();
                double rtaresta = resta(numero, numero2);
                System.out.println("El resultado de la resta es: " + rtaresta);
                break;
            case 3:
                System.out.println("Digite dos numeros: ");
                numero = sc.nextDouble();
                numero2 = sc.nextDouble();
                double rtamultiplicacion = multiplicacion(numero, numero2);
                System.out.println("El resultado de la multiplicacion es: " + rtamultiplicacion);

            case 4:
                System.out.println("Digite dos numeros: ");
                numero = sc.nextDouble();
                numero2 = sc.nextDouble();
                double rtadivision = division(numero, numero2);
                System.out.println("El resultado de la division es : " + rtadivision);
                break;
            case 5:
                salir = true;
                break;
            default:
                System.out.println("Solamente digite las opciones correctas!!!");//(LEE Y ADVIERTE DEL ERROR EN CONSOLA

        }

    }

    public static double suma(double numer, double numero) {
        return numer + numero;

    }

    public static double resta(double num1, double num2) {
        return num1 - num2;
    }

    public static double multiplicacion(double num1, double num2) {
        return num1 * num2;
    }

    public static double division(double num1, double num2) {
        return num1 / num2;
    }
}
