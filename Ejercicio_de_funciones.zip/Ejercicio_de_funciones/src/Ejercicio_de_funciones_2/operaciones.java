
package Ejercicio_de_funciones_2;

public class operaciones {
public static double suma(double numer, double numero) {
        return numer + numero;

    }

    public static double resta(double num1, double num2) {
        return num1 - num2;
    }

    public static double multiplicacion(double num1, double num2) {
        return num1 * num2;
    }

    public static double division(double num1, double num2) {
        return num1 / num2;
    }
}
