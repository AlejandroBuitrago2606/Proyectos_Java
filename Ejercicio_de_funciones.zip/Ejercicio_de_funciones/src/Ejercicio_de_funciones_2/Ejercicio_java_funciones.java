package Ejercicio_de_funciones_2;

import java.util.Scanner;

public class Ejercicio_java_funciones {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        operaciones df = new operaciones();
        boolean salir = false;
        double numero, numero2;
        System.out.println("*********************");
        System.out.println("1. suma");
        System.out.println("2. Resta");
        System.out.println("3. Multiplicacion");
        System.out.println("4. Division");
        System.out.println("5. Salir");
        System.out.println("*********************");
        System.out.println("Escoja un opcion");
        int op = sc.nextInt();
        switch (op) {
            case 1:
                System.out.println("Digite dos numeros: ");
                numero = sc.nextDouble();
                numero2 = sc.nextDouble();
                double rtasuma = df.suma(numero, numero2);//aqui llamo la otra funcion
                System.out.println("El resultado de la suma es: " + rtasuma);
                break;
            case 2:
                System.out.println("Digite dos numeros: ");
                numero = sc.nextDouble();
                numero2 = sc.nextDouble();
                double rtaresta = df.resta(numero, numero2);
                System.out.println("El resultado de la resta es: " + rtaresta);
                break;
            case 3:
                System.out.println("Digite dos numeros: ");
                numero = sc.nextDouble();
                numero2 = sc.nextDouble();
                double rtamultiplicacion = df.multiplicacion(numero, numero2);
                System.out.println("El resultado de la multiplicacion es: " + rtamultiplicacion);

            case 4:
                System.out.println("Digite dos numeros: ");
                numero = sc.nextDouble();
                numero2 = sc.nextDouble();
                double rtadivision = df.division(numero, numero2);
                System.out.println("El resultado de la division es : " + rtadivision);
                break;
            case 5:
                salir = true;
                break;
            default:
                System.out.println("Solamente digite las opciones correctas!!!");//(LEE Y ADVIERTE DEL ERROR EN CONSOLA

        }
    }
}
