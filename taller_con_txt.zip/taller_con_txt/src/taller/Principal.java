package taller;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Principal {

    public static void main(String[] args) throws IOException {

        Scanner sc = new Scanner(System.in);

        System.out.println("Ingresa el id del establecimiento: ");
        String id = sc.nextLine();
        System.out.println("Ingresa el nit: ");
        String nit = sc.nextLine();
        System.out.println("Ingresa el nombre del establecimiento: ");
        String establecimiento = sc.nextLine();
        System.out.println("Ingresa el año de creacion: ");
        String año = sc.nextLine();
        System.out.println("Ingresa el nombre del propietario: ");
        String propietario = sc.nextLine();
        System.out.println("pago Matricula si o no: ");
        String pago = sc.nextLine();
        System.out.println("Ingresa la fecha de pago: ");
        String fecha = sc.nextLine();
        System.out.println("Observaciones: ");
        String Obser = sc.nextLine();

        Establecimiento estab = new Establecimiento(establecimiento, nit, Obser, propietario, propietario, pago, fecha, Obser);
        escribirArchivo("Establecimiento.txt", estab);
        
    }

     private static void escribirArchivo(String nombreArchivo, Establecimiento estable)throws IOException{
        FileWriter writer= new FileWriter(nombreArchivo,true);
        writer.write(estable.toString());
        writer.write("\n\n");//diferenciar peliculas
        writer.close();
        System.out.println("Se escribio en el archivo exitosamente");
        
    }
    private static void listar() throws IOException{
        try {
            BufferedReader reader = new BufferedReader(new BufferedReader(new FileReader("Establecimiento.txt")));
            String linea;
            System.out.println("Establecimiento");
            while ((linea = reader.readLine()) != null) {
                System.out.println(linea);

            }
            reader.close();

        } catch (IOException e) {
            System.out.println("Error al leer el archivo" + e.getMessage());
        }

    }
    /*private static void agregarpelicula(Scanner sc) throws IOException {

        System.out.println("Ingrese efl titulo de la pelicula");
        String titulo = sc.nextLine();
        System.out.println("Ingrese el pais donde se hizo la pelicula");
        String pais = sc.nextLine();
        System.out.println("Ingrese el director de la pelicula");
        String director = sc.nextLine();
        System.out.println("Ingrese el idioma de la pelicula");
        String idioma = sc.nextLine();
        System.out.println("Ingrese el genero de la pelicula");
        String genero = sc.nextLine();
        System.out.println("Ingrese la clasificacion de la pelicula");
        String clasificacion = sc.nextLine();
        System.out.println("Ingrese la duracion de la pelicula");
        String duracion = sc.nextLine();
        System.out.println("Ingrese el anio de la pelicula");
        String anio = sc.nextLine();
        System.out.println("Ingrese la sipnosis de la pelicula");
        String sipnosis = sc.nextLine();
        sc.next();
    }

    private static void escribirArchivo(String nombreArchivo, Establecimiento pelicula) throws IOException {
        FileWriter writer = new FileWriter(nombreArchivo, true);
        writer.write(pelicula.toString());
        writer.write("\n\n");//Espacio para diferenciar entre peliculas
        writer.close();
        System.out.println("Se escribio en el Archivo Exitosamente!!!");

    }

    private static void listarPeliculas() {
        try {
            BufferedReader reader = new BufferedReader(new BufferedReader(new FileReader("pelicula.txt")));
            String linea;
            System.out.println("Lista de peliculas");
            while ((linea = reader.readLine()) != null) {
                System.out.println(linea);

            }
            reader.close();

        } catch (IOException e) {
            System.out.println("Error al leer el archivo" + e.getMessage());
        }

    }
     */
}
