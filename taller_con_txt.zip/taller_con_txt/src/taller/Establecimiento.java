package taller;

public class Establecimiento {

    private String id_establecimiento;
    private String nit;
    private String nombre;
    private String aniocreacion;
    private String nombrepropietario;
    private String pagoMatricula;
    private String fechaPago;
    private String Observaciones;

    public Establecimiento(String id_establecimiento, String nit, String nombre, String aniocreacion, String nombrepropietario, String pagoMatricula, String fechaPago, String Observaciones) {
        this.id_establecimiento = id_establecimiento;
        this.nit = nit;
        this.nombre = nombre;
        this.aniocreacion = aniocreacion;
        this.nombrepropietario = nombrepropietario;
        this.pagoMatricula = pagoMatricula;
        this.fechaPago = fechaPago;
        this.Observaciones = Observaciones;
    }

    public String getId_establecimiento() {
        return id_establecimiento;
    }

    public void setId_establecimiento(String id_establecimiento) {
        this.id_establecimiento = id_establecimiento;
    }

    public String getNit() {
        return nit;
    }

    public void setNit(String nit) {
        this.nit = nit;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getAniocreacion() {
        return aniocreacion;
    }

    public void setAniocreacion(String aniocreacion) {
        this.aniocreacion = aniocreacion;
    }

    public String getNombrepropietario() {
        return nombrepropietario;
    }

    public void setNombrepropietario(String nombrepropietario) {
        this.nombrepropietario = nombrepropietario;
    }

    public String getPagoMatricula() {
        return pagoMatricula;
    }

    public void setPagoMatricula(String pagoMatricula) {
        this.pagoMatricula = pagoMatricula;
    }

    public String getFechaPago() {
        return fechaPago;
    }

    public void setFechaPago(String fechaPago) {
        this.fechaPago = fechaPago;
    }

    public String getObservaciones() {
        return Observaciones;
    }

    public void setObservaciones(String Observaciones) {
        this.Observaciones = Observaciones;
    }

    @Override
    public String toString() {
        return "Establecimiento" + 
                "\nid_establecimiento= " + id_establecimiento + 
                "\n nit=" + nit + 
                "\n nombre=" + nombre + 
                "\n aniocreacion=" + aniocreacion + 
                "\n nombrepropietario=" + nombrepropietario +
                "\n pagoMatricula=" + pagoMatricula + 
                "\n fechaPago=" + fechaPago + 
                "\n Observaciones=" + Observaciones;
    }
    
    
    
    

}
